-- ======================================================================
-- erika_blinker.ctl generated from erika_blinker
-- 10/31/2018 at 11:13
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
