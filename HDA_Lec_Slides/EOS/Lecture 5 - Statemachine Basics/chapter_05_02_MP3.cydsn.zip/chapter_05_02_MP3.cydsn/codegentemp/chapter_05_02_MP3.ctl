-- ======================================================================
-- chapter_05_02_MP3.ctl generated from chapter_05_02_MP3
-- 11/26/2019 at 18:44
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
