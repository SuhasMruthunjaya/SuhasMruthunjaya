/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "global.h"
#include "trcRecorder.h"

#include "led.h"
#include "seven.h"


//Global handles for Tracealyser
traceHandle TRC_SystickHandle;
traceHandle TRC_ISRButtonHandle;

#undef TRC_SYSTICK

//ISR which will increment the systick counter every ms
ISR(systick_handler)
{
#ifdef TRC_SYSTICK
    vTraceStoreISRBegin(TRC_SystickHandle);
#endif   
    
    CounterTick(cnt_systick);

#ifdef TRC_SYSTICK
    vTraceStoreISREnd(0);
#endif   

}

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
   
    //Set systick period to 1 ms. Enable the INT and start it.
	EE_systick_set_period(MILLISECONDS_TO_TICKS(1, BCLK__BUS_CLK__HZ));
	EE_systick_enable_int();
    
    //Enable trace
    vTraceEnable(TRC_INIT);
    TRC_SystickHandle = xTraceSetISRProperties("SysTick", 1);
    TRC_ISRButtonHandle = xTraceSetISRProperties("ISR_Button", 1);
   
    // Start Operating System
    for(;;)	    
    	StartOS(OSDEFAULTAPPMODE);
}

void unhandledException()
{
    //Ooops, something terrible happened....check the call stack to see how we got here...
    __asm("bkpt");
}

/********************************************************************************
 * Task Definitions
 ********************************************************************************/

TASK(tsk_init)
{
    
    //Init MCAL Drivers
    UART_LOG_Start();
    
    LED_Init();
    SEVEN_Init();
        
    //Reconfigure ISRs with OS parameters.
    //This line MUST be called after the hardware driver initialisation!
    EE_system_init();
    
	
    //Start SysTick
	//Must be done here, because otherwise the isr vector is not overwritten yet
    EE_systick_start();  
	
    //Start the cyclic alarms 
    SetRelAlarm(alrm_cyclic,100,100);
    SetRelAlarm(alrm_trace,200,200); 

    //Activate all extended and the background task
    ActivateTask(tsk_event);
    ActivateTask(tsk_background);
    
    TerminateTask();
    
}

TASK(tsk_cyclic)
{
    LED_Toggle(LED_RED);
    TerminateTask();
}

TASK(tsk_event)
{
 
    EventMaskType ev = 0;
    uint32_t delayInMs = 0;
    while(1)
    {
        WaitEvent (ev_Button_1 | ev_Button_2 | ev_Button_3 | ev_Button_4);
        GetEvent(tsk_event, &ev);
        ClearEvent(ev);
        
        if (ev & ev_Button_1)
        {
            delayInMs = 100;
            SEVEN_Set(SEVEN_0,1);
        }

        if (ev & ev_Button_2)
        {
            delayInMs = 500;
            SEVEN_Set(SEVEN_0,2);
        }
        
        if (ev & ev_Button_3)
        {
            delayInMs = 1000;
            SEVEN_Set(SEVEN_0,3);
        }
        
        if (ev & ev_Button_4)
        {
            delayInMs = 1500;
            SEVEN_Set(SEVEN_0,4);
        }
    
        //Use up some time
        LED_Set(LED_GREEN, LED_ON);
        
        //Don't try this at home!!!!
        CyDelay(delayInMs);
        
        LED_Set(LED_GREEN, LED_OFF);
    }
    
    TerminateTask();
}

TASK(tsk_background)
{
    while(1)
    {
        //do something with low prioroty
        __asm("nop");
    }
}


/********************************************************************************
 * ISR Definitions
 ********************************************************************************/


ISR2(isr_Button)
{
    vTraceStoreISRBegin(TRC_ISRButtonHandle);

    if (BUTTON_1_Read() == 1) SetEvent(tsk_event,ev_Button_1);   
    if (BUTTON_2_Read() == 1) SetEvent(tsk_event,ev_Button_2);   
    if (BUTTON_3_Read() == 1) SetEvent(tsk_event,ev_Button_3);   
    if (BUTTON_4_Read() == 1) SetEvent(tsk_event,ev_Button_4);   
    
    vTraceStoreISREnd(0);
}

/* [] END OF FILE */
