-- ======================================================================
-- w04_events.ctl generated from w04_events
-- 11/19/2019 at 18:36
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
