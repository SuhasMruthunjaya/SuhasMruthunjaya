

package state_machine_definitions;

	enum logic [1:0] {__RESET = 2'b00, __IDLE = 2'b01, __PROC = 2'b10, __DONE = 2'b11} state;
	// ...  

endpackage 


module sha1_state_machine(
	input logic clk,
	input logic reset_n,
	input logic start,

	input logic [31:0] data_0,
	input logic [31:0] data_1,
	input logic [31:0] data_2,
	
	...
	
	output logic [31:0] q_data,

	// for illustration purposes only ... 	
	output logic q_start,
	output logic q_done,
	output logic [1:0] q_control,
	output logic [1:0] q_state

);

	import state_machine_definitions::*;
	
	
	localparam LOOP_ITERATIONS = 120;
	localparam ITERATIONS      = LOOP_ITERATIONS - 1;
	localparam BITWIDTH        = $clog2(ITERATIONS);
	
	

	/* ### start pulse detection ##############################################
	
	CPU asserts a start pulse ...
	
										  ___________________________________________________
	start_signal:		__________|                                                   |_______________________________________
	
										 ^
										 |
										 
								 ACTUAL START
						
	
	We are using the start_signal to derive a 50MHz related start pulse ..., which is only high for 20ns ... 
	
							             _
							____________| |________________________________________________________________________________________
	
	
	We use this start pulse to trigger our sha-1 processing stage ...
	
	*/
	
	// with the following structure, we are detecting the rising edge of our start signal ... 
	
	logic [3:0] sync_reg = 0;
	
	// shifting data (start signal) from the right-hand side. shifting everything to the left ... newest data is placed at the LSB side ...
	always_ff@(posedge clk)
		begin : start_detection
			if(reset_n == 1'b0)
				sync_reg <= 4'b0000;
			else
				sync_reg <= {sync_reg[2:0],start};
		
		end : start_detection

	// comparator that continuously evaluates the content of our sync_reg ...
	logic sync_start; assign sync_start = (sync_reg == 4'b0011) ? 1'b1 : 1'b0; 

	assign q_start = sync_start;
	
	// ### 'state-machine' ... #######################################################################################################
		
	logic [1:0] control = 0;	
		
	logic [BITWIDTH-1:0] state_counter = 'd0;
	
	always_ff@(posedge clk)
		begin : state_machine
			if(reset_n == 1'b0)
				begin
					control       <= 0;
					state_counter <= 0;
					state 		  <= __RESET;
				end
			else
				begin
					case(state)
						__RESET:	
							begin
								control       <= 0;
								state_counter <= 0;
								state 		  <= __IDLE;
							end	
						__IDLE: 
							begin
								state_counter <= 0;
								control       <= 0;
								
								if(sync_start)
									state <= __PROC;
							end
						__PROC: 
							begin
								/*
									do something meaningful ... , the control signal is just used for illustration purposes ...
								*/
							
								if(state_counter < 10)
									control <= 2'b01;
								else if(state_counter >= 10 && state_counter < 64)
									control <= 2'b10;
								else if(state_counter >= 64 && state_counter < 110)
									control <= 2'b00;
								else
									control <= 2'b11;
							
								if(state_counter == ITERATIONS)
									begin
										state_counter <= 0;
										state         <= __DONE;
									end
								else
									begin
										state_counter <= state_counter + 1;
										state         <= __PROC;
									end
							end
						__DONE:
							begin
								control       <= 0;
								state_counter <= 0;
								state			  <= __IDLE;
							end
						default:
							begin
								control       <= 0;
								state_counter <= 0;
								state 		  <= __RESET;
							end
					endcase
				end
			end : state_machine
				
				
			assign q_done = (state == __DONE) ? 1'b1 : 1'b0;
				
			assign q_control = control;
			assign q_state   = state;

endmodule 