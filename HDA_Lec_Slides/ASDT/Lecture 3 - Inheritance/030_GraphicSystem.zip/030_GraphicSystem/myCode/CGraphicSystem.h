/*
 * CGraphicSystem.h
 *
 *  Created on: 20.10.2019
 *      Author: Fromm
 */

#ifndef CGRAPHICSYSTEM_H_
#define CGRAPHICSYSTEM_H_
#include "CSquare.h"
#include "CTriangle.h"
#include "CCircle.h"
#include "CScreen.h"

class CGraphicSystem
{
private:

	/**
	 * Note: For the sake of coding simplicity, I did not implement a full database for all the objects here
	 * But instead only provided a hacky prototyping solution in order to create some objects and testcases
	 */

    /**@link aggregationByValue
     * @supplierCardinality 0..**/
    CSquare m_square[3];
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 0..**/
    CTriangle m_triangle[3];
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 0..**/
    CCircle m_circle[3];
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 2*/
    CScreen m_screen[2];
public:

    /**
     * Constructor
     */
	CGraphicSystem();

	/**
	 * A simple testcase...
	 */
	void run();
};

#endif /* CGRAPHICSYSTEM_H_ */
