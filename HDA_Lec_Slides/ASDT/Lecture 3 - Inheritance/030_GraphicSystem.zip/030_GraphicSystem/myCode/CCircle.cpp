

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCIRCLE.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files
#include <iostream>
using namespace std;

//Own Include Files
#include "CCircle.h"

//Method Implementations



CCircle::CCircle(std::string name, float radius, int x, int y) : CGraphicalObject(1, name)
{
	m_radius = radius;
	setCoordinate(0,x,y);
}

void CCircle::print()
{
	cout << "My special circle print" << endl;
	cout << "Radius: " << m_radius << endl;

	//Let's try to call the base class print
	//CGraphicalObject::print();

	//Using protected member
	cout << "Name: " << m_name << endl;
	m_pCoordinate[0].print();
}
