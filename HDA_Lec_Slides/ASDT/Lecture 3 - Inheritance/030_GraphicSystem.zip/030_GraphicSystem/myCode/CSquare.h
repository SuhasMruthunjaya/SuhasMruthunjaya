/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSQUARE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CSQUARE_H
#define CSQUARE_H
#include "CGraphicalObject.h"

#include <string>

class CSquare : public CGraphicalObject {
public:

    CSquare(std::string name = "SQUARE", int x1 = 0, int y1 = 0, int x2 = 1, int y2 = 1);
};
/********************
**  CLASS END
*********************/
#endif /* CSQUARE_H */
