

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCOORDINATE.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files
#include <iostream>
using namespace std;

//Own Include Files
#include "CCoordinate.h"

//Method Implementations

/**
 * The constructor of the coordinate,
 * which also allows you to set an initial value
 * @param int x		- The initial x value, default 0 (IN)
 * @param int y		- The initial y value, default 0 (IN)
 */
CCoordinate::CCoordinate(int x, int y)
{
	m_x = x;
	m_y = y;
}

/**
 * Print a single coordinate
 * @returnvalue void
 */
void CCoordinate::print()
{
	cout << "( " << m_x << ", " << m_y << " )" << endl;

}

/**
 * Returns the current coordinate value by reference
 * @param int & x	- the current x value (OUT)
 * @param int & y	- the current y value (OUT)
 */
void CCoordinate::get(int & x, int & y)
{
	x = m_x;
	y = m_y;
}

/**
 * Sets the current coordinate value
 * @param int x	- the new x value (IN)
 * @param int y	- the new y value (IN)
 */
void CCoordinate::set(int x, int y)
{
	m_x = x;
	m_y = y;
}
