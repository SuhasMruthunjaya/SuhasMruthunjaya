/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCOORDINATE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCOORDINATE_H
#define CCOORDINATE_H
class CCoordinate {
private:
    /**
     * The y coordinate value 
     */
    int m_y;
    /**
     * The x coordinate value 
     */
    int m_x;
public:

    /**
     * The constructor of the coordinate,
     * which also allows you to set an initial value
     * @param int x		- The initial x value, default 0 (IN)
     * @param int y		- The initial y value, default 0 (IN)
     */
    CCoordinate(int x = 0, int y = 0);

    /**
     * Print a single coordinate
     * @returnvalue void
     */
    void print();

    /**
     * Returns the current coordinate value by reference
     * @param int & x	- the current x value (OUT)
     * @param int & y	- the current y value (OUT)
     */
    void get(int & x, int & y);

    /**
     * Sets the current coordinate value
     * @param int x	- the new x value (IN)
     * @param int y	- the new y value (IN)
     */
    void set(int x, int y);


};
/********************
**  CLASS END
*********************/
#endif /* CCOORDINATE_H */
