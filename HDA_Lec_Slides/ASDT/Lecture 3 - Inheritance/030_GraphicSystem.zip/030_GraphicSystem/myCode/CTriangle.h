/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CTRIANGLE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CTRIANGLE_H
#define CTRIANGLE_H
#include "CGraphicalObject.h"
class CTriangle : public CGraphicalObject {
public:

    CTriangle();
};
/********************
**  CLASS END
*********************/
#endif /* CTRIANGLE_H */
