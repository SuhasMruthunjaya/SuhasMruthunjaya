

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CGRAPHICALOBJECT.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files
#include <iostream>
using namespace std;

//Own Include Files
#include "CGraphicalObject.h"
#include "CCoordinate.h"

//Method Implementations

CGraphicalObject::CGraphicalObject(unsigned short noCoordinates,
		std::string name)
{
	m_size = noCoordinates;
	//m_nextFreePosition = 0;
	m_name = name;

	m_pCoordinate = new CCoordinate[m_size];
}

//Todo: Copy cosntructor

CGraphicalObject::~CGraphicalObject()
{
	delete[] m_pCoordinate;
}
void CGraphicalObject::print()
{
	cout << "Graphical Object: " << m_name << endl;

	for (int i = 0; i < m_size; i++)
	{
		m_pCoordinate[i].print();
	}

}


void CGraphicalObject::setCoordinate(unsigned short pos, int x, int y)
{
	if (pos < m_size)
	{
		m_pCoordinate[pos].set(x,y);


	}

}

CGraphicalObject& CGraphicalObject::operator =(const CGraphicalObject &origin)
{
	if (&origin == this)
	{
		//nothing to do, somebody wrote a = a;
		return *this;
	}

	if (m_size != origin.m_size)
	{
		//size is different, we have to allocate new memory
		delete[] m_pCoordinate;
		m_pCoordinate = new CCoordinate[origin.m_size];
	}

	m_name = origin.m_name;
	m_size = origin.m_size;

	//This enforces a deep copy
	for (unsigned int i = 0; i < m_size; i++)
	{
		m_pCoordinate[i] = origin.m_pCoordinate[i];
	}

	return *this;
}

CGraphicalObject::CGraphicalObject(const CGraphicalObject &origin)
{
	m_name = origin.m_name;
	m_size = origin.m_size;

	//This would be a - not required - schallow copy
	//m_pCoordinate = origin.m_pCoordinate;

	//This enforces a deep copy
	m_pCoordinate = new CCoordinate[m_size];
	for (unsigned int i = 0; i < m_size; i++)
	{
		m_pCoordinate[i] = origin.m_pCoordinate[i];
	}

}
