/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSCREEN.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CSCREEN_H
#define CSCREEN_H
#include "CCircle.h"
#include <string>
#include "CSquare.h"
#include "CTriangle.h"


class CScreen {
private:
	std::string m_name;
    unsigned short m_size;
    unsigned short m_nextFreePos;
    /**@link aggregation
     * @supplierCardinality 0..*
     * @clientCardinality 1*/
    CCircle** m_p_ObjectEntry;
    /**@link aggregation
     * @supplierCardinality 0..*
     * @clientCardinality 1*/
    CSquare lnkCSquare;
    /**@link aggregation
     * @supplierCardinality 0..*
     * @clientCardinality 1*/
    CTriangle lnkCTriangle;
public:
    CScreen(std::string name = "SCREEN", unsigned short size = 10);

    ~CScreen();

    void setName(std::string name);

    void print();

    void addCircleReference(CCircle  *const circle);

    void addCircleReference(CCircle const& circle);

};
/********************
**  CLASS END
*********************/
#endif /* CSCREEN_H */
