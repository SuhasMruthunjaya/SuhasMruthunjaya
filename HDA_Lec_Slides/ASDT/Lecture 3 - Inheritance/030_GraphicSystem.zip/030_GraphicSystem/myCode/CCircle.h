/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCIRCLE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCIRCLE_H
#define CCIRCLE_H
#include "CGraphicalObject.h"
#include <string>

class CCircle : public CGraphicalObject {
private:
    float m_radius;
public:

    CCircle(std::string name = "EmptyCircle", float radius = 1, int x = 0, int y = 0);

    void print();
};
/********************
**  CLASS END
*********************/
#endif /* CCIRCLE_H */
