

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSQUARE.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files
#include "CSquare.h"

//Method Implementations


CSquare::CSquare(std::string name, int x1, int y1, int x2, int y2) : CGraphicalObject(2, name)
{
	setCoordinate(0,x1,y1);
	setCoordinate(1,x2, y2);
}
