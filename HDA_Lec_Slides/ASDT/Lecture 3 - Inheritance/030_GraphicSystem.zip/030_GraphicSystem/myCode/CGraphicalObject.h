/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CGRAPHICALOBJECT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CGRAPHICALOBJECT_H
#define CGRAPHICALOBJECT_H
#include <string>

#include "CCoordinate.h"

class CGraphicalObject {
protected:
	std::string m_name;
    //unsigned short m_nextFreePosition;
    unsigned short m_size;
    /**@link aggregationByValue
     * @supplierCardinality 1..*
     * @clientCardinality 1*/
    CCoordinate* m_pCoordinate;
public:

    //Todo: commenting

    void print();

    void setCoordinate(unsigned short pos, int x, int y);

    ~CGraphicalObject();

    CGraphicalObject(unsigned short noCoordinates = 1, std::string name = "GraphicalObject");

    //Assignemnt Operator required for deep copy
    CGraphicalObject& operator=(CGraphicalObject const& origin);

    //Copy Constructor
    CGraphicalObject(CGraphicalObject const& origin);
};
/********************
**  CLASS END
*********************/
#endif /* CGRAPHICALOBJECT_H */
