/*
 * CGraphicSystem.cpp
 *
 *  Created on: 20.10.2019
 *      Author: Fromm
 */

#include <iostream>
using namespace std;

#include "CGraphicSystem.h"

CGraphicSystem::CGraphicSystem()
{
	//Nothing to be done here

}

void CGraphicSystem::run()
{
	m_square[0] = CSquare("My first square", 1, 1, 2, 3);
	m_circle[0] = CCircle("My first circle", 10, 4, 4);
	m_circle[1] = CCircle ("My 2 circle", 20, 4, 4);
	m_circle[2] = CCircle ("My 3 circle", 30, 4, 4);




	m_screen[0].setName("Screen 1");
	m_screen[1].setName("Screen 2");

	m_screen[0].addCircleReference(&m_circle[0]);
	m_screen[0].addCircleReference(&m_circle[1]);

	m_screen[1].addCircleReference(&m_circle[2]);
	m_screen[1].addCircleReference(&m_circle[1]);

	m_screen[0].print();
	m_screen[1].print();
}
