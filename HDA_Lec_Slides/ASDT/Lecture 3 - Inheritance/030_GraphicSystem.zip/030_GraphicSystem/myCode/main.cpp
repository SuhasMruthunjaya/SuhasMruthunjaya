// GIT-Labor
// main.h

////////////////////////////////////////////////////////////////////////////////
// Header-Dateien
#include <iostream>		// Header f�r die Standard-IO-Objekte (z.B. cout, cin)
#include <stdlib.h>
using namespace std;

#include "CGraphicSystem.h"

// Dient als Testrahmen, von hier aus werden die Klassen aufgerufen
int main (void)
{

	CGraphicSystem g1;

	g1.run();



	return 0;
}
