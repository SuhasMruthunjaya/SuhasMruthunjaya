

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSCREEN.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files
#include <iostream>
using namespace std;

//Own Include Files
#include "CScreen.h"
#include "CCircle.h"


//Method Implementations


CScreen::~CScreen(){}


CScreen::CScreen(string name, unsigned short size)
{
	m_name = name;
	m_nextFreePos = 0;
	m_size = size;

	m_p_ObjectEntry = new CGraphicalObject* [m_size];

	for (int i = 0; i < m_size; i++)
	{
		m_p_ObjectEntry[i] = 0;
	}
}

void CScreen::print()
{
	cout << "========================================" << endl;
	cout << "Printing screen: " << m_name << endl;

	for (int i = 0; i < m_nextFreePos; i++)
	{
		cout << "Printing object at adress " << m_p_ObjectEntry[i] << endl;
		m_p_ObjectEntry[i]->print();
	}
}


void CScreen::setName(std::string name)
{
	m_name = name;
}

void CScreen::addObjectReference(CGraphicalObject *const object)
{
	if (m_nextFreePos < m_size)
	{
		m_p_ObjectEntry[m_nextFreePos++] = object;
	}
}
