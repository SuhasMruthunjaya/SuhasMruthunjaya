/*
 * CGraphicSystem.cpp
 *
 *  Created on: 20.10.2019
 *      Author: Fromm
 */

#include <iostream>
using namespace std;

#include "CGraphicSystem.h"

#include "CCircle.h"
#include "CSquare.h"

CGraphicSystem::CGraphicSystem()
{
	//Nothing to be done here

}

void CGraphicSystem::run()
{
	m_GraphicalObject[0] = new CSquare("My first square", 1, 1, 2, 3);
	m_GraphicalObject[1] = new  CCircle("My first circle", 10, 4, 4);
	m_GraphicalObject[2] = new  CCircle ("My 2 circle", 20, 4, 4);
	m_GraphicalObject[3] = new  CCircle ("My 3 circle", 30, 4, 4);




	m_screen[0].setName("Screen 1");
	m_screen[1].setName("Screen 2");

	m_screen[0].addObjectReference(m_GraphicalObject[0]);
	m_screen[0].addObjectReference(m_GraphicalObject[1]);

	m_screen[1].addObjectReference(m_GraphicalObject[2]);
	m_screen[1].addObjectReference(m_GraphicalObject[3]);


	m_screen[0].print();
	m_screen[1].print();
}
