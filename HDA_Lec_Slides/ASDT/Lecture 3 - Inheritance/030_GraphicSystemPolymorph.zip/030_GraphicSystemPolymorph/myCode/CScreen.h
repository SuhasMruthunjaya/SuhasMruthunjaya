/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSCREEN.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CSCREEN_H
#define CSCREEN_H

#include <string>

#include "CGraphicalObject.h"

class CScreen {
private:
	std::string m_name;
    unsigned short m_size;
    unsigned short m_nextFreePos;
    /**@link aggregation
     * @supplierCardinality 0..*
     * @clientCardinality 1*/
    CGraphicalObject** m_p_ObjectEntry;
public:
    CScreen(std::string name = "SCREEN", unsigned short size = 10);

    ~CScreen();

    void setName(std::string name);

    void print();

    void addObjectReference(CGraphicalObject  *const object);



};
/********************
**  CLASS END
*********************/
#endif /* CSCREEN_H */
