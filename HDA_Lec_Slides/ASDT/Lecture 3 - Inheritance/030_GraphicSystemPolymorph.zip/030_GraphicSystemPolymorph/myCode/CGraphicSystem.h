/*
 * CGraphicSystem.h
 *
 *  Created on: 20.10.2019
 *      Author: Fromm
 */

#ifndef CGRAPHICSYSTEM_H_
#define CGRAPHICSYSTEM_H_


#include "CGraphicalObject.h"
#include "CScreen.h"

class CGraphicSystem
{
private:

	/**
	 * This might be replaced by a proper database later on
	 * @link aggregationByValue
	 * @supplierCardinality 0..*
	 */
	CGraphicalObject* m_GraphicalObject[10];
    /**
     * @link aggregationByValue
     * @supplierCardinality 1 
     */
	CScreen m_screen[2];


public:

    /**
     * Constructor
     */
	CGraphicSystem();

	/**
	 * A simple testcase...
	 */
	void run();
};

#endif /* CGRAPHICSYSTEM_H_ */
