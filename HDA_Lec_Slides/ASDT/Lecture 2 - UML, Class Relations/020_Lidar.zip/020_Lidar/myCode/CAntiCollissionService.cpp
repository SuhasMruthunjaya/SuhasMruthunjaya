#include "CAntiCollissionService.h"
#include "CLidarBuffer.h"
#include "CLidarValue.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CANTICOLLISSIONSERVICE.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

CAntiCollissionService::CAntiCollissionService(uint16_t maxLidarValues)
{
	m_ppLidarValue = new CLidarValue*[maxLidarValues];
}
