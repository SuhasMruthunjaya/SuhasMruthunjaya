/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CPWM.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CPWM_H
#define CPWM_H
#include "CDriver.h"
class CPWM : public CDriver {
private:
    int m_rotationSpeed;
};
/********************
**  CLASS END
*********************/
#endif /* CPWM_H */
