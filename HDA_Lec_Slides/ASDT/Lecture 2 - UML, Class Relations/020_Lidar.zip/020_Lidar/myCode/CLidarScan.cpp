#include "CLidarScan.h"
#include "CLidarValue.h"


/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CLIDARSCAN.CPP
* Author          :
* Description     :
*
*
****************************************************************************/

//System Include Files


//Own Include Files

//Method Implementations


CLidarValue CLidarScan::get()
{
	return CLidarValue(0,0,0);
}
void CLidarScan::put(CLidarValue data)
{

}
CLidarScan::~CLidarScan(){}

CLidarScan::CLidarScan(uint16_t noElements){
	m_pLidarValue = new CLidarValue[noElements];
}
bool CLidarScan::scanComplete()
{
	return false;
}


uint16_t CLidarScan::getNumberOfElements()
{
	return m_noElements;
}
