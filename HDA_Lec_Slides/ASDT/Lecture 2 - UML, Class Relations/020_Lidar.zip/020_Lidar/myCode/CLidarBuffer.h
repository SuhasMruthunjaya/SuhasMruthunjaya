/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CLIDARBUFFER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CLIDARBUFFER_H
#define CLIDARBUFFER_H

#include "global.h"
#include "CLidarScan.h"
#include "CLidarValue.h"

class CLidarBuffer {
private:
    uint16_t m_readArray;
    uint16_t m_writeArray;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 2*/
    CLidarScan m_LidarScan[2];
public:

    CLidarBuffer();

    void put(CLidarValue const& data);

    CLidarValue getElementAtPos(unsigned int pos);

    void flipReadWrite();

    unsigned int getNumberOfStoredElements();

};
/********************
**  CLASS END
*********************/
#endif /* CLIDARBUFFER_H */
