/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CANTICOLLISSIONSERVICE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CANTICOLLISSIONSERVICE_H
#define CANTICOLLISSIONSERVICE_H

#include "CLidarBuffer.h"
#include "CLidarValue.h"

class CAntiCollissionService {
private:
    CLidarBuffer * m_pLidarBuffer;
    /**@link aggregation
     * @clientCardinality 1
     * @supplierCardinality **/
    CLidarValue ** m_ppLidarValue;
public:

    CAntiCollissionService(uint16_t maxLidarValues);
};
/********************
**  CLASS END
*********************/
#endif /* CANTICOLLISSIONSERVICE_H */
