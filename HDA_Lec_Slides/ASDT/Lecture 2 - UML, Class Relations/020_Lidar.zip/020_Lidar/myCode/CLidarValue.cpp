#include "CLidarValue.h"

//System Include Files


//Own Include Files

//Method Implementations



/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CLIDARVALUE.CPP
* Author          :
* Description     :
*
*
****************************************************************************/
CLidarValue::CLidarValue(uint8_t quality, uint16_t angle, uint16_t distance)
{

}


uint16_t CLidarValue::getDistance()
{

	return 0;
}

uint8_t CLidarValue::getQuality()
{
	return 0;
}

uint16_t CLidarValue::getAngle()
{
	return 0;
}
