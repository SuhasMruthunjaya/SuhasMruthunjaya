/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CLIDARVALUE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CLIDARVALUE_H
#define CLIDARVALUE_H

#include "global.h"

class CLidarValue {
private:
	uint8_t m_quality;
    uint16_t m_distance;
    uint16_t m_angle;
public:

    CLidarValue(uint8_t quality = 0, uint16_t angle = 0, uint16_t distance = 0);

    uint8_t getQuality();

    uint16_t getDistance();

    uint16_t getAngle();


};
/********************
**  CLASS END
*********************/
#endif /* CLIDARVALUE_H */
