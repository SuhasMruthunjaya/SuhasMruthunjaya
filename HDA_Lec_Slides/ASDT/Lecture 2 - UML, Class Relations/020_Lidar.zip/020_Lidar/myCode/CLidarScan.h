/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CLIDARSCAN.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CLIDARSCAN_H
#define CLIDARSCAN_H
#include "global.h"
#include "CLidarValue.h"

class CLidarScan {
private:
    uint16_t m_readIdx;
    uint16_t m_writeIdx;
    uint16_t m_noElements;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality **/
    CLidarValue* m_pLidarValue;
public:

    CLidarScan(uint16_t noElements = 400);

    ~CLidarScan();

    void put(CLidarValue data);

    CLidarValue get();

    uint16_t getNumberOfElements();

    bool scanComplete();
};
/********************
**  CLASS END
*********************/
#endif /* CLIDARSCAN_H */
