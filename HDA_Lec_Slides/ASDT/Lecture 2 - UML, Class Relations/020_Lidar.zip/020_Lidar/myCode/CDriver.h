/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CDRIVER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CDRIVER_H
#define CDRIVER_H
class CDriver {
public:

    virtual void deinit() =0;

    virtual void init() =0;

    virtual void read() =0;

    virtual void write() =0;

    CDriver();
};
/********************
**  CLASS END
*********************/
#endif /* CDRIVER_H */
