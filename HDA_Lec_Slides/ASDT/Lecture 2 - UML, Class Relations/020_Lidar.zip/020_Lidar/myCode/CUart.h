/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUART.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CUART_H
#define CUART_H
#include "CDriver.h"
class CLidarBuffer;
class CUart : public CDriver {
private:
    CLidarBuffer * m_pLidarBuffer;
};
/********************
**  CLASS END
*********************/
#endif /* CUART_H */
