
/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CLIDARBUFFER.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files
#include "CLidarBuffer.h"
#include "CLidarScan.h"
#include "CLidarValue.h"


//Method Implementations

CLidarBuffer::CLidarBuffer()
{

}

unsigned int CLidarBuffer::getNumberOfStoredElements()
{
	return m_LidarScan[m_readArray].getNumberOfElements();
}

CLidarValue CLidarBuffer::getElementAtPos(unsigned int pos)
{

	return CLidarValue(0,0,0);
}


