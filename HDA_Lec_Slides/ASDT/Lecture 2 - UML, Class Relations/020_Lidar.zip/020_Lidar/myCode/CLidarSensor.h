/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CLIDARSENSOR.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CLIDARSENSOR_H
#define CLIDARSENSOR_H
#include "CLidarBuffer.h"
#include "CUart.h"
#include "CPWM.h"
#include "CAntiCollissionService.h"
class CLidarSensor {
private:
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1*/
    CLidarBuffer m_LidarBuffer;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1*/
    CUart m_Uart;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1*/
    CPWM m_PWM;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1*/
    CAntiCollissionService lnkCAntiCollissionService;
};
/********************
**  CLASS END
*********************/
#endif /* CLIDARSENSOR_H */
