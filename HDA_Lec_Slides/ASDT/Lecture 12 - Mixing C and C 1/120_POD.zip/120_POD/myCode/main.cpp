// Standard (system) header files
#include <iostream>
#include <stdlib.h>
#include <string>

using namespace std;


typedef struct pod1{
	int m_a;
	int m_b;

/*
	pod1()
	{
		m_a = 99;
		m_b = 77;
	}
*/
	void print()
	{
		cout << "my pod1_t: " << m_a << ", " << m_b << endl;
	}
} pod1_t;

pod1_t data1 = {2,3};

//==================================================

class coordinate
{
private:
	int m_x;
	int m_y;
};


// Main program
int main (void)
{

	data1.print();

	return 0;
}
