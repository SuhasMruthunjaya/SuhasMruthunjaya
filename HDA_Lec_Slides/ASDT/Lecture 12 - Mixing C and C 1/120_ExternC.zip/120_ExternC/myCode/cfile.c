/*
 * cfile.c
 *
 *  Created on: 18.01.2020
 *      Author: Fromm
 */

#include "cfile.h"
#include "cppfile.h"

#include <stdio.h>

void foo()
{
	printf("cfile foo()\n");

	//This come from a c++ file
	foofoo();

	//Method call through wrapper
	CfoofooWrapper("Hello C++ object");
}
