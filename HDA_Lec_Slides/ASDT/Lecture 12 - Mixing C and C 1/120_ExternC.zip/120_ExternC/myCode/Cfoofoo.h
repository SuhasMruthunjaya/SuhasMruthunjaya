/*
 * Cfoofoo.h
 *
 *  Created on: 18.01.2020
 *      Author: Fromm
 */

#ifndef CFOOFOO_H_
#define CFOOFOO_H_

#include <string>

class Cfoofoo
{
private:
	std::string m_content;

public:
	Cfoofoo(std::string content);

	void print();
};

#endif /* CFOOFOO_H_ */
