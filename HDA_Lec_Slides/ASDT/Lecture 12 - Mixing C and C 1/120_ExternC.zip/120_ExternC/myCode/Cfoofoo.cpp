/*
 * Cfoofoo.cpp
 *
 *  Created on: 18.01.2020
 *      Author: Fromm
 */

#include "Cfoofoo.h"

#include <iostream>
using namespace std;

Cfoofoo::Cfoofoo(std::string content)
{
	m_content = content;
}

void Cfoofoo::print()
{
	cout << "Cfoofoo: " << m_content << endl;
}
