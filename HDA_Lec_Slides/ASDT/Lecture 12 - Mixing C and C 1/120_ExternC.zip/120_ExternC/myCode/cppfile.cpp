/*
 * cppfile.cpp
 *
 *  Created on: 18.01.2020
 *      Author: Fromm
 */

#include "cppfile.h"
#include "Cfoofoo.h"

#include <iostream>
using namespace std;

extern "C"
{

void foofoo()
{
	cout << "cppfile foofoo with C-Linkage" << endl;
}


void CfoofooWrapper(char* text)
{
	Cfoofoo obj(text);
	obj.print();
}


}
