// Standard (system) header files
#include <iostream>
#include <stdlib.h>
// Add more standard header files as required
// #include <string>

using namespace std;

#include "cfile.h"



int main (void)
{
    // TODO: Add your program code here
	foo();

	return 0;
}
