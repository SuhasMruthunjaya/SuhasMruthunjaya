/*
 * cfile.h
 *
 *  Created on: 18.01.2020
 *      Author: Fromm
 */

#ifndef CFILE_H_
#define CFILE_H_


//As extern "C" is only known to C++ compiler, we have to hide it in case the ehader file is included from a C-File
#ifdef __cplusplus

//This tell will the file including this header that foo is linked with C-linkage!
extern "C"
{

#endif

void foo();

#ifdef __cplusplus
}
#endif //extern "C"

#endif /* CFILE_H_ */
