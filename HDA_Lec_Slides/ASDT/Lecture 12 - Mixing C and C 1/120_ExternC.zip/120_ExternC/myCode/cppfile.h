/*
 * cppfile.h
 *
 *  Created on: 18.01.2020
 *      Author: Fromm
 */

#ifndef CPPFILE_H_
#define CPPFILE_H_

#ifdef __cplusplus
	extern "C"
	{
#endif


		void foofoo();

		//Name conflict when using string.h
		void CfoofooWrapper(char* text);

#ifdef __cplusplus
	}
#endif




#endif /* CPPFILE_H_ */
