// Standard (system) header files
#include <iostream>
#include <stdlib.h>
// Add more standard header files as required
// #include <string>

using namespace std;


struct s1{
	int m_a;
	int m_b;

	s1(int a=0, int b=0)
	{
		m_a = a;
		m_b = b;
	}

	void print()
	{
		cout << "my pod1_t: " << m_a << ", " << m_b << endl;
	}

} ;

// Main program
int main (void)
{
	s1 data;
	data = 2;

	data.print();

	return 0;
}
