/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CFILTER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CFILTER_H
#define CFILTER_H
class CFilter {
};
/********************
**  CLASS END
*********************/
#endif /* CFILTER_H */
