/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCONTROL.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCONTROL_H
#define CCONTROL_H
#include "CFilter.h"
class CEngine;
class CRemote;
class CControl {
private:
    CRemote m_remote;
    /**
     * @supplierCardinality 0..4 
     */
    CEngine m_engine[4];
    /**@link dependency*/
    /*# CFilter lnkCFilter; */
public:

    void control();
};
/********************
**  CLASS END
*********************/
#endif /* CCONTROL_H */
