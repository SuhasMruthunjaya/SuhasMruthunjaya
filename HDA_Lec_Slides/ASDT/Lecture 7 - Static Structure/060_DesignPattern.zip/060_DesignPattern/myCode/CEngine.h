/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CENGINE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CENGINE_H
#define CENGINE_H
#include "CCanOpen.h"
class CEngine {
private:
    /**@supplierCardinality 1*/
    CCanOpen* m_pCCanOpen;
};
/********************
**  CLASS END
*********************/
#endif /* CENGINE_H */
