/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUARTPROTOCOL.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CUARTPROTOCOL_H
#define CUARTPROTOCOL_H
#include "CUartDriver.h"
class CRingBuffer;
class CUartProtocol {
private:
    /**@link aggregationByValue
     * @supplierCardinality 1*/
    CUartDriver m_CUartDriver;
    /**
     * @link aggregationByValue 
     * @supplierCardinality 1
     */
    CRingBuffer * m_CRingBuffer;
};
/********************
**  CLASS END
*********************/
#endif /* CUARTPROTOCOL_H */
