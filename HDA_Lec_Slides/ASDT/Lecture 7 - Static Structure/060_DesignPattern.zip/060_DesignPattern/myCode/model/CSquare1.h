/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSQUARE1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CSQUARE1_H
#define CSQUARE1_H
#include "CGraphicObject.h"
#include "CGraphicObject1.h"
class CSquare1 : public CGraphicObject1 {
public:

    void print();
};
/********************
**  CLASS END
*********************/
#endif /* CSQUARE1_H */
