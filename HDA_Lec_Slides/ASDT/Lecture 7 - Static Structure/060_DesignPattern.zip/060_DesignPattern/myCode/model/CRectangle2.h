/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CRECTANGLE2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CRECTANGLE2_H
#define CRECTANGLE2_H
#include "CGraphicObject.h"
#include "CGraphicObject1.h"
#include "CCorneredObject.h"
class CRectangle2 : public CCorneredObject {
};
/********************
**  CLASS END
*********************/
#endif /* CRECTANGLE2_H */
