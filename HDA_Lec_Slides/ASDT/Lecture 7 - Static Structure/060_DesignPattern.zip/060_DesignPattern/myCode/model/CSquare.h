/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSQUARE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CSQUARE_H
#define CSQUARE_H
#include "CGraphicObject.h"
class CSquare : public CGraphicObject {
};
/********************
**  CLASS END
*********************/
#endif /* CSQUARE_H */
