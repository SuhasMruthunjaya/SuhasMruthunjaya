/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUARTDRIVER_HIGHCOHESION.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CUARTDRIVER_HIGHCOHESION_H
#define CUARTDRIVER_HIGHCOHESION_H
class CRingBuffer;
class CUartDriver_highCohesion {
private:
    CRingBuffer * m_rx_CRingBuffer;
    CRingBuffer * m_Tx_CRingBuffer;
public:

    CUartDriver_highCohesion(CRingbuffer* rx_buffer, CRingbuffer* tx_buffer);

    RC_t write(uint8_t data);
    RC_t read(uint8_t & data);

    void isr_tx();
    void isr_rx();
};
/********************
**  CLASS END
*********************/
#endif /* CUARTDRIVER_HIGHCOHESION_H */
