/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CRINGBUFFER1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CRINGBUFFER1_H
#define CRINGBUFFER1_H
class CRingBuffer1 {
};
/********************
**  CLASS END
*********************/
#endif /* CRINGBUFFER1_H */
