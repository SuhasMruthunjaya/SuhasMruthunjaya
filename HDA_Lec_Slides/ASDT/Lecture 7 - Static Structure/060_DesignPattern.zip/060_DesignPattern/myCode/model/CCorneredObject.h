/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCORNEREDOBJECT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCORNEREDOBJECT_H
#define CCORNEREDOBJECT_H
#include "CGraphicObject2.h"
class CCorneredObject : public CGraphicObject2 {
public:

    void print();
};
/********************
**  CLASS END
*********************/
#endif /* CCORNEREDOBJECT_H */
