/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUARTPROTOCOL1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CUARTPROTOCOL1_H
#define CUARTPROTOCOL1_H
#include "CUartDriver.h"
#include <CUartDriver.h>
#include "CUartDriver1.h"
class CRingBuffer1;
class CRingBuffer;
class CUartProtocol1 {
private:
    /**@link aggregationByValue
     * @supplierCardinality 1*/
    CUartDriver1 m_CUartDriver;
    /**
     * @link aggregationByValue 
     * @supplierCardinality 1
     */
    CRingBuffer1 * m_CRingBuffer;
};
/********************
**  CLASS END
*********************/
#endif /* CUARTPROTOCOL1_H */
