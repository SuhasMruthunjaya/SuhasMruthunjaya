#include "CUartDriver_highCohesion.h"
#include "CRingBuffer.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUARTDRIVER_HIGHCOHESION.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

CUartDriver_highCohesion::CUartDriver_highCohesion(){}
