/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUARTDRIVER1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CUARTDRIVER1_H
#define CUARTDRIVER1_H
#include "CRingBuffer.h"
#include <CRingBuffer.h>
#include "CRingBuffer1.h"
class CUartDriver1 {
private:
    /**@supplierCardinality 1
     * @link association*/
    CRingBuffer1 m_pCRingBuffer;
};
/********************
**  CLASS END
*********************/
#endif /* CUARTDRIVER1_H */
