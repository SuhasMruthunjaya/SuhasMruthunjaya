/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CRECTANGLE1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CRECTANGLE1_H
#define CRECTANGLE1_H
#include "CGraphicObject.h"
#include "CGraphicObject1.h"
class CRectangle1 : public CGraphicObject1 {
public:

    void print();
};
/********************
**  CLASS END
*********************/
#endif /* CRECTANGLE1_H */
