/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSQUARE2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CSQUARE2_H
#define CSQUARE2_H
#include "CGraphicObject.h"
#include "CGraphicObject1.h"
#include "CCorneredObject.h"
class CSquare2 : public CCorneredObject {
};
/********************
**  CLASS END
*********************/
#endif /* CSQUARE2_H */
