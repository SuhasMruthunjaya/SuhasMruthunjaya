/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CGRAPHICOBJECT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CGRAPHICOBJECT_H
#define CGRAPHICOBJECT_H
class CGraphicObject {
private:
    CCorner m_corner;
public:

    void print();
};
/********************
**  CLASS END
*********************/
#endif /* CGRAPHICOBJECT_H */
