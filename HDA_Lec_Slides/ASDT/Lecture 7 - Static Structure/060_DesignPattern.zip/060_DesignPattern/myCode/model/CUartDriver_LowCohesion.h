/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUARTDRIVER_LOWCOHESION.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CUARTDRIVER_LOWCOHESION_H
#define CUARTDRIVER_LOWCOHESION_H
class CRingBuffer;
class CUartDriver_LowCohesion {
private:
    uint16_t m_size_tx;
    uint16_t m_fillLevel_tx;
    uint16_t m_readIdx_tx;
    uint16_t m_writeIdx_tx;
    uint8_t * m_pBuffer_tx;

    uint16_t m_size_rx;
    uint16_t m_fillLevel_rx;
    uint16_t m_readIdx_rx;
    uint16_t m_writeIdx_rx;
    uint8_t * m_pBuffer_rx;
    string m_EOPPattern;
public:

    CUartDriver_LowCohesion(uint16_t size_rx, uint16_t size_tx);

    RC_t write(uint8_t data);
    RC_t read(uint8_t & data);

    boolean_t checkEOP();

    void isr_tx();
    void isr_rx();

private:
    RC_t put_tx(uint8_t data);
    RC_t put_rx(uint8_t data);
    RC_t get_tx(uint8_t& data);
    RC_t get_rx(uint8_t& data);
    void clear_tx();
    void clear_rx();
};
/********************
**  CLASS END
*********************/
#endif /* CUARTDRIVER_LOWCOHESION_H */
