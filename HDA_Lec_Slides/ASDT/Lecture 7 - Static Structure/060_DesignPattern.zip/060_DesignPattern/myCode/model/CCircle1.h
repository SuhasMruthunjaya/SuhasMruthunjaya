/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCIRCLE1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCIRCLE1_H
#define CCIRCLE1_H
#include "CGraphicObject.h"
#include "CGraphicObject1.h"
class CCircle1 : public CGraphicObject1 {
public:

    void print();
};
/********************
**  CLASS END
*********************/
#endif /* CCIRCLE1_H */
