/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCIRCLE2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCIRCLE2_H
#define CCIRCLE2_H
#include "CGraphicObject.h"
#include "CGraphicObject1.h"
#include "CGraphicObject2.h"
class CCircle2 : public CGraphicObject2 {
public:

    void print();
};
/********************
**  CLASS END
*********************/
#endif /* CCIRCLE2_H */
