/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CGRAPHICOBJECT2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CGRAPHICOBJECT2_H
#define CGRAPHICOBJECT2_H
class CGraphicObject2 {
private:
    CCorner m_corner;
public:

    virtual void print() =0;
};
/********************
**  CLASS END
*********************/
#endif /* CGRAPHICOBJECT2_H */
