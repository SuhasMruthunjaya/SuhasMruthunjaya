/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CGRAPHICOBJECT1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CGRAPHICOBJECT1_H
#define CGRAPHICOBJECT1_H
class CGraphicObject1 {
private:
    CCorner m_corner;
public:

    virtual void print() =0;
};
/********************
**  CLASS END
*********************/
#endif /* CGRAPHICOBJECT1_H */
