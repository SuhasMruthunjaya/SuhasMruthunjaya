/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCIRCLE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCIRCLE_H
#define CCIRCLE_H
#include "CGraphicObject.h"
class CCircle : public CGraphicObject {
public:

    void print();
};
/********************
**  CLASS END
*********************/
#endif /* CCIRCLE_H */
