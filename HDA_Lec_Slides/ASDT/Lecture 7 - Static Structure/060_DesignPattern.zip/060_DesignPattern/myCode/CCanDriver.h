/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCANDRIVER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCANDRIVER_H
#define CCANDRIVER_H
#include "CRingBuffer.h"
class CCanDriver {
};
/********************
**  CLASS END
*********************/
#endif /* CCANDRIVER_H */
