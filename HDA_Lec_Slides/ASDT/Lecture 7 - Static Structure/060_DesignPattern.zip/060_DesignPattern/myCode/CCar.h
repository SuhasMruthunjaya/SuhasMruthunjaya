/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCAR.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCAR_H
#define CCAR_H
#include "CControl.h"
#include "CRemote.h"
#include "CEngine.h"
#include "CCanOpen.h"
class CCar {
private:
    /**@link aggregationByValue
     * @supplierCardinality 1*/
    CControl m_CControl;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1*/
    CRemote m_CRemote;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 4*/
    CEngine m_CEngine;
    /**@link aggregationByValue*/
    CCanOpen lnkCCanOpen;
};
/********************
**  CLASS END
*********************/
#endif /* CCAR_H */
