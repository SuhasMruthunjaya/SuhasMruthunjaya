/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUARTDRIVER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CUARTDRIVER_H
#define CUARTDRIVER_H
#include "CRingBuffer.h"
class CUartDriver {
private:
    /**@supplierCardinality 1
     * @link association*/
    CRingBuffer m_pCRingBuffer;
};
/********************
**  CLASS END
*********************/
#endif /* CUARTDRIVER_H */
