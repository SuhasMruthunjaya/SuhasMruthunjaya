/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CREMOTE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CREMOTE_H
#define CREMOTE_H
#include "CUartProtocol.h"
class CRemote {
private:
    /**@link aggregationByValue
     * @supplierCardinality 1*/
    CUartProtocol m_CUartProtocol;
};
/********************
**  CLASS END
*********************/
#endif /* CREMOTE_H */
