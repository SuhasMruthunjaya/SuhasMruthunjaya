/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CRINGBUFFER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CRINGBUFFER_H
#define CRINGBUFFER_H
class CRingBuffer {
private:
    uint16_t m_size;
    uint16_t m_fillLevel;
    uint16_t m_readIdx;
    uint16_t m_writeIdx;

    uint8_t * m_pBuffer;
public:

    CRingBuffer(uint16_t size = 10);
    ~CRingbuffer()
    RC_t put(uint8_t data);
    RC_t get(uint8_t& data);
    void clear();

};
/********************
**  CLASS END
*********************/
#endif /* CRINGBUFFER_H */
