/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CCANOPEN.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CCANOPEN_H
#define CCANOPEN_H
#include "CCanDriver.h"
#include "CRingBuffer.h"
class CCanOpen {
private:
    /**@link aggregationByValue
     * @supplierCardinality 1*/
    CCanDriver m_CCanDriver;
    /**@link aggregationByValue*/
    CRingBuffer m_CRingBuffer;
};
/********************
**  CLASS END
*********************/
#endif /* CCANOPEN_H */
