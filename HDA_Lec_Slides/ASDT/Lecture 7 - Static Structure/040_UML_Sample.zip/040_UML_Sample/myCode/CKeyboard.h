/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CKEYBOARD.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CKEYBOARD_H
#define CKEYBOARD_H

#include <string>

class CKeyboard {
public:

    unsigned int getNumber(std::string);
};
/********************
**  CLASS END
*********************/
#endif /* CKEYBOARD_H */
