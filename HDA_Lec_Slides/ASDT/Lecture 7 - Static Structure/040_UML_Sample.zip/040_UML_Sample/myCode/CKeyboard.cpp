

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CKEYBOARD.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files
#include <iostream>
using namespace std;

//Own Include Files
#include "CKeyboard.h"

//Method Implementations

unsigned int CKeyboard::getNumber(string text)
{
	unsigned int result;

	cout << text << " : ";
	cin >> result;

	return result;
}
