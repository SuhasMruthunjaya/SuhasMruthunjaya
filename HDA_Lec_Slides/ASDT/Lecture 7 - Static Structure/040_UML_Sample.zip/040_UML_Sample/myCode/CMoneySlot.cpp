

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CMONEYSLOT.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files
#include <iostream>
using namespace std;

//Own Include Files
#include "CMoneySlot.h"

//Method Implementations

void CMoneySlot::deliver(unsigned int amount)
{
	cout << "Delivered: "<< amount << " Euros" << endl;

}

CMoneySlot::CMoneySlot(){}
