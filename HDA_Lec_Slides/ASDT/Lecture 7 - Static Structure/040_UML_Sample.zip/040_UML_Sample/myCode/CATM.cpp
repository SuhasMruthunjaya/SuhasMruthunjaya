

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CATM.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files
#include "CATM.h"

//Method Implementations

CATM::CATM()
{
	m_authenticated = false;
	m_account = 0;

	m_databaseReplication.addUser(CAccount("Willi", 1111, 1111, 500));
	m_databaseReplication.addUser(CAccount("Mary", 2222, 2222 , 1500));
	m_databaseReplication.addUser(CAccount("Joe", 3333, 3333, 5000));
	m_databaseReplication.addUser(CAccount("Willi's other account", 4444, 4444, 0));

}


void CATM::run()
{
	while (!m_authenticated)
	{
		authenticate();
	}

	m_screen.printMessage("1 - Withdraw money");
	m_screen.printMessage("2 - Transfer money");

	unsigned int choice = m_keyboard.getNumber("Your choice");

	switch (choice)
	{
	case 1 : withdrawMoney(); break;
	case 2 : transferMoney(); break;
	default : m_screen.printMessage("Wrong key"); break;
	}
}


bool CATM::authenticate()
{
	m_screen.printMessage("Welcome to your local ATM machine");
	unsigned int account = m_keyboard.getNumber("Please enter your account");
	unsigned short pin = m_keyboard.getNumber("Please enter your PIN");

	if (m_databaseReplication.authenticateUser(account, pin))
	{
		m_authenticated = true;
		m_account = account;
		return true;
	}

	return false;
}



void CATM::transferMoney()
{
	m_screen.printMessage("Selected: Transfer Money");
	unsigned int amount = m_keyboard.getNumber("Amount");
	unsigned int toAccount = m_keyboard.getNumber("To Account");

	if (m_databaseReplication.checkIfAccountExists(toAccount))
	{
		if (m_databaseReplication.getDeposit(m_account) > amount)
		{
			//All ok
			m_databaseReplication.payIntoAccount(toAccount, amount);
			m_databaseReplication.withdrawFromAccount(m_account, amount);
			m_screen.printMessage("Done");
		}
		else
		{
			m_screen.printMessage("Error: your account is to low");
		}
	}
	else
	{
		m_screen.printMessage("Recipient not found");
	}
}

void CATM::withdrawMoney()
{
}
