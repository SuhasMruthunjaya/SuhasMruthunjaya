/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CACCOUNT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CACCOUNT_H
#define CACCOUNT_H

#include <string>

class CAccount {
private:
    unsigned short m_pin;
    float m_deposit;
    unsigned int m_accountNo;
    std::string m_customer;
public:

    CAccount (std::string customer = "", unsigned int account = 0, unsigned short pin = 0,  float deposit = 0);
	unsigned int getAccountNo() const;
	void setAccountNo(unsigned int accountNo);
	const std::string& getCustomer() const;
	void setCustomer(const std::string &customer);
	float getDeposit() const;
	void setDeposit(float deposit);
	unsigned short getPin() const;
	void setPin(unsigned short pin);

	void addAmount(float amount);
	void deductAmount(float amount);
};
/********************
**  CLASS END
*********************/
#endif /* CACCOUNT_H */
