/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CMONEYSLOT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CMONEYSLOT_H
#define CMONEYSLOT_H
class CMoneySlot {
public:

    CMoneySlot();

    void deliver(unsigned int amount);
};
/********************
**  CLASS END
*********************/
#endif /* CMONEYSLOT_H */
