

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CDATABASEREPLICATION.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files
#include <iostream>
using namespace std;

//Own Include Files
#include "CDatabaseReplication.h"
#include "CAccount.h"

//Method Implementations
CDatabaseReplication::CDatabaseReplication()
{
	//DO nothing
}

void CDatabaseReplication::payIntoAccount(unsigned int account, float amount)
{
	auto itr = m_accountDatabase.find(account);

	if (itr != m_accountDatabase.end())
	{
		//found the entry
		itr->second.addAmount(amount);
	}
	else
	{
		cout << "Database: account not found" << endl;
	}

}


void CDatabaseReplication::withdrawFromAccount(unsigned int accountNo,
		float amount)
{

	auto itr = m_accountDatabase.find(accountNo);

	if (itr != m_accountDatabase.end())
	{
		//found the entry
		itr->second.deductAmount(amount);
	}
	else
	{
		cout << "Database: account not found" << endl;
	}

}

bool CDatabaseReplication::authenticateUser(unsigned int account,
		unsigned short pin)
{
	auto itr = m_accountDatabase.find(account);

	if (itr != m_accountDatabase.end())
	{
		//found the entry
		return itr->second.getPin() == pin;
	}
	else
	{
		return false;
	}
}

void CDatabaseReplication::addUser(const CAccount &user)
{
	m_accountDatabase[user.getAccountNo()] = user;
}

float CDatabaseReplication::getDeposit(unsigned int account)
{
	auto itr = m_accountDatabase.find(account);

	if (itr != m_accountDatabase.end())
	{
		//found the entry
		return itr->second.getDeposit();
	}
	else
	{
		cout << "Database: account not found" << endl;
		return false;
	}

}

bool CDatabaseReplication::checkIfAccountExists(unsigned int account)
{
	auto itr = m_accountDatabase.find(account);

	if (itr != m_accountDatabase.end())
	{
		return true;
	}
	else
	{
		return false;
	}
}
