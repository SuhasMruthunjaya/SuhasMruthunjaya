

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CACCOUNT.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files
#include "CAccount.h"

//Method Implementations



unsigned int CAccount::getAccountNo() const
{
	return m_accountNo;
}

void CAccount::setAccountNo(unsigned int accountNo)
{
	m_accountNo = accountNo;
}

const std::string& CAccount::getCustomer() const
{
	return m_customer;
}

void CAccount::setCustomer(const std::string &customer)
{
	m_customer = customer;
}

 float CAccount::getDeposit() const
{
	return m_deposit;
}

void CAccount::setDeposit( float deposit)
{
	m_deposit = deposit;
}

unsigned short CAccount::getPin() const
{
	return m_pin;
}

CAccount::CAccount(std::string customer, unsigned int account,
		unsigned short pin,  float deposit)
{
	m_customer = customer;
	m_accountNo = account;
	m_pin = pin;
	m_deposit = deposit;

}

void CAccount::setPin(unsigned short pin)
{
	m_pin = pin;
}

void CAccount::addAmount(float amount)
{
	m_deposit += amount;
}

void CAccount::deductAmount(float amount)
{
	m_deposit -=amount;
}
