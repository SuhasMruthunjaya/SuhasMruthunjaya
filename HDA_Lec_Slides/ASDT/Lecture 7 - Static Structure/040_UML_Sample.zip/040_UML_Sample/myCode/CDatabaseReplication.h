/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CDATABASEREPLICATION.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CDATABASEREPLICATION_H
#define CDATABASEREPLICATION_H

#include <map>

#include "CAccount.h"

class CDatabaseReplication {

std::map<unsigned int, CAccount> m_accountDatabase;


public:

    CDatabaseReplication();

    void payIntoAccount(unsigned int account, float amount);


    void withdrawFromAccount(unsigned int accountNo, float amount);

    bool authenticateUser(unsigned int account, unsigned short pin);

    void addUser(CAccount const& user);

    float getDeposit(unsigned int account);

    bool checkIfAccountExists(unsigned int account);




};
/********************
**  CLASS END
*********************/
#endif /* CDATABASEREPLICATION_H */
