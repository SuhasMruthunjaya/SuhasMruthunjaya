

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSCREEN.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files
#include <iostream>
using namespace std;

//Own Include Files
#include "CScreen.h"

//Method Implementations

void CScreen::printMessage(string message)
{
	cout << "SCREEN: " << message << endl;

}
