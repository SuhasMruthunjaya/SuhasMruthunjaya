/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : SCREEN_INTERFACE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef SCREEN_INTERFACE_H
#define SCREEN_INTERFACE_H
class Screen_interface {
};
/********************
**  CLASS END
*********************/
#endif /* SCREEN_INTERFACE_H */
