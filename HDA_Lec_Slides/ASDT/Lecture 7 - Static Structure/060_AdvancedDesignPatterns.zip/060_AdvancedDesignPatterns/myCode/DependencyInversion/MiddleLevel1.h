/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : MIDDLELEVEL1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef MIDDLELEVEL1_H
#define MIDDLELEVEL1_H
class MiddleLevel1 {
};
/********************
**  CLASS END
*********************/
#endif /* MIDDLELEVEL1_H */
