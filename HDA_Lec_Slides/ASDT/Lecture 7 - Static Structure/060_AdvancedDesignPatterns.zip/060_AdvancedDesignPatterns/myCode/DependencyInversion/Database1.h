/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : DATABASE1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef DATABASE1_H
#define DATABASE1_H
#include "Database_Interface.h"
class Database1 : public Database_Interface {
};
/********************
**  CLASS END
*********************/
#endif /* DATABASE1_H */
