/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : HIGHLEVEL.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef HIGHLEVEL_H
#define HIGHLEVEL_H
class HighLevel {
};
/********************
**  CLASS END
*********************/
#endif /* HIGHLEVEL_H */
