/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : DATABASE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef DATABASE_H
#define DATABASE_H
class Database {
};
/********************
**  CLASS END
*********************/
#endif /* DATABASE_H */
