/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : LOWLEVEL1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef LOWLEVEL1_H
#define LOWLEVEL1_H
class LowLevel1 {
};
/********************
**  CLASS END
*********************/
#endif /* LOWLEVEL1_H */
