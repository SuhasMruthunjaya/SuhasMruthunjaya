/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : MIDDLELEVEL2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef MIDDLELEVEL2_H
#define MIDDLELEVEL2_H
class MiddleLevel2 {
};
/********************
**  CLASS END
*********************/
#endif /* MIDDLELEVEL2_H */
