/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : LOWLEVEL3.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef LOWLEVEL3_H
#define LOWLEVEL3_H
class LowLevel3 {
};
/********************
**  CLASS END
*********************/
#endif /* LOWLEVEL3_H */
