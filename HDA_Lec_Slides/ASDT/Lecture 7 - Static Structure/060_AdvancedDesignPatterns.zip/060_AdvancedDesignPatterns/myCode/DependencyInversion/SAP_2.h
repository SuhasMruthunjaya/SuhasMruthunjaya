/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : SAP_2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef SAP_2_H
#define SAP_2_H
#include "Screen_interface.h"
#include "Database_Interface.h"
class SAP_2 {
private:
    /**@link aggregationByValue*/
    Screen_interface lnkScreen_interface;
    /**@link aggregationByValue*/
    Database_Interface lnkDatabase_Interface;
};
/********************
**  CLASS END
*********************/
#endif /* SAP_2_H */
