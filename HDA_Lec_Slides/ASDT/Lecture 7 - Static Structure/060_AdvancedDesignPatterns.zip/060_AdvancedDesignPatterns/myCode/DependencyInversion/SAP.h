/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : SAP.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef SAP_H
#define SAP_H
#include "Screen.h"
#include "Database.h"
class SAP {
private:
    /**@link aggregationByValue*/
    Screen lnkScreen;
    /**@link aggregationByValue*/
    Database lnkDatabase;
};
/********************
**  CLASS END
*********************/
#endif /* SAP_H */
