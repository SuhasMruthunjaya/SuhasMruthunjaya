/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : SCREEN2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef SCREEN2_H
#define SCREEN2_H
#include "Screen_interface.h"
class Screen2 : public Screen_interface {
};
/********************
**  CLASS END
*********************/
#endif /* SCREEN2_H */
