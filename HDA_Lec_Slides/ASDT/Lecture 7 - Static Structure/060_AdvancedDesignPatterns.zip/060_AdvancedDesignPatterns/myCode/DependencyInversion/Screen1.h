/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : SCREEN1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef SCREEN1_H
#define SCREEN1_H
#include "Screen_interface.h"
class Screen1 : public Screen_interface {
};
/********************
**  CLASS END
*********************/
#endif /* SCREEN1_H */
