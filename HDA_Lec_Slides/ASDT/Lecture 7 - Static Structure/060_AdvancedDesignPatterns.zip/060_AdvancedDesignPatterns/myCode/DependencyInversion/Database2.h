/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : DATABASE2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef DATABASE2_H
#define DATABASE2_H
#include "Database_Interface.h"
class Database2 : public Database_Interface {
};
/********************
**  CLASS END
*********************/
#endif /* DATABASE2_H */
