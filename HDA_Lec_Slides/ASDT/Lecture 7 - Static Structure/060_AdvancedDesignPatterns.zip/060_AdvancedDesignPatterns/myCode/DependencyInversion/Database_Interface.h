/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : DATABASE_INTERFACE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef DATABASE_INTERFACE_H
#define DATABASE_INTERFACE_H
class Database_Interface {
};
/********************
**  CLASS END
*********************/
#endif /* DATABASE_INTERFACE_H */
