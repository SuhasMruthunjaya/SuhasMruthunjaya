/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : LOWLEVEL2.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef LOWLEVEL2_H
#define LOWLEVEL2_H
class LowLevel2 {
};
/********************
**  CLASS END
*********************/
#endif /* LOWLEVEL2_H */
