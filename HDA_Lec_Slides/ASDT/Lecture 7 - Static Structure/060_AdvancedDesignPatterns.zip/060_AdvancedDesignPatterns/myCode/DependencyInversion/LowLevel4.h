/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : LOWLEVEL4.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef LOWLEVEL4_H
#define LOWLEVEL4_H
class LowLevel4 {
};
/********************
**  CLASS END
*********************/
#endif /* LOWLEVEL4_H */
