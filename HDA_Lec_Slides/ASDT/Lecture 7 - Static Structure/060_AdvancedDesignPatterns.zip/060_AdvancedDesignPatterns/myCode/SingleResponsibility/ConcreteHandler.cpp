/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CONCRETEHANDLER.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations
#include "ConcreteHandler.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : HANDLER.CPP
* Author          :
* Description     :
*
*
****************************************************************************/
void ConcreteHandler::handleRequest(){
        if (getSuccessor() != 0) {
            getSuccessor()->handleRequest();
        }

// Write your code here
    }
