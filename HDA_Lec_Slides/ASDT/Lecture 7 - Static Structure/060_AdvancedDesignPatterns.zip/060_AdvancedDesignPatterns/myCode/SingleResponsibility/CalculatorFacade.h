/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CALCULATORFACADE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CALCULATORFACADE_H
#define CALCULATORFACADE_H
#include "PayCalculator.h"
#include "BudgetCalculator.h"
#include "EmployeeData.h"
class CalculatorFacade : public PayCalculator, public BudgetCalculator {
private:
    /**@link aggregationByValue
     * @supplierCardinality 1*/
    EmployeeData lnkEmployeeData;
};
/********************
**  CLASS END
*********************/
#endif /* CALCULATORFACADE_H */
