#include "Handler.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : HANDLER.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

void Handler::handleRequest(){
        if (successor != 0) {
            successor->handleRequest();
        }

// Write your code here
    }
void Handler::setSuccessor(Handler* successor){
        this->successor = successor;
    }
Handler* Handler::getSuccessor(){
        return successor;
    }
