/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : EMPLOYEEDATA.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef EMPLOYEEDATA_H
#define EMPLOYEEDATA_H
class EmployeeData {
private:
    int employeeData;
public:

    void set();

    void get();
};
/********************
**  CLASS END
*********************/
#endif /* EMPLOYEEDATA_H */
