#include "EmployeeData.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : EMPLOYEEDATA.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

void EmployeeData::get(){}
void EmployeeData::set(){}
