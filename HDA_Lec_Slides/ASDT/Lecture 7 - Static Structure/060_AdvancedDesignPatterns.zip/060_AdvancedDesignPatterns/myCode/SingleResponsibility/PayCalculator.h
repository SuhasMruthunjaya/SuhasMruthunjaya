/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : PAYCALCULATOR.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef PAYCALCULATOR_H
#define PAYCALCULATOR_H
#include "EmployeeData.h"
class PayCalculator {
private:
    /**@link aggregation
     * @supplierCardinality 1*/
    EmployeeData lnkEmployeeData;
public:


    void calculatePay();
private:
    void reportHours();
};
/********************
**  CLASS END
*********************/
#endif /* PAYCALCULATOR_H */
