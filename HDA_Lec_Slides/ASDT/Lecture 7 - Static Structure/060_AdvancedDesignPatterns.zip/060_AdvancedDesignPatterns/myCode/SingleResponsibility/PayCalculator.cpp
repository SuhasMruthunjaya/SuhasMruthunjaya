#include "PayCalculator.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : PAYCALCULATOR.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

void PayCalculator::calculatePay(){}
void PayCalculator::reportHours(){}
