/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : HANDLER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef HANDLER_H
#define HANDLER_H
#include "ConcreteHandler.h"
class Handler {
private:
    /**
     * @link aggregation 
     */
    Handler* successor;
    /**
     * @link
     * @shapeType PatternLink
     * @pattern Chain of Responsibility
     * @supplierRole Concrete handlers 
     */
    /*# ConcreteHandler _concreteHandler; */
public:

    void handleRequest();

    void setSuccessor(Handler* successor);

    Handler* getSuccessor();
};
/********************
**  CLASS END
*********************/
#endif /* HANDLER_H */
