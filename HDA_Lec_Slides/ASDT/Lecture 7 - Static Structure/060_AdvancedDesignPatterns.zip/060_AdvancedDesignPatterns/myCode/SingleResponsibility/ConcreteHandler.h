/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CONCRETEHANDLER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CONCRETEHANDLER_H
#define CONCRETEHANDLER_H
#include "Handler.h"
class ConcreteHandler : public Handler {
public:

    void handleRequest();
};
/********************
**  CLASS END
*********************/
#endif /* CONCRETEHANDLER_H */
