#include "BudgetCalculator.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : BUDGETCALCULATOR.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

void BudgetCalculator::saveBudget(){}
void BudgetCalculator::reportHours(){}
