#include "Employee.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : EMPLOYEE.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

void Employee::calculatePay(){}
void Employee::reportHours(){}
void Employee::saveBudget(){}
