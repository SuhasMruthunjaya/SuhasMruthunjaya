/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : BUDGETCALCULATOR.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef BUDGETCALCULATOR_H
#define BUDGETCALCULATOR_H
#include "EmployeeData.h"
class BudgetCalculator {
private:
    /**@link aggregation
     * @supplierCardinality 1*/
    EmployeeData lnkEmployeeData;
public:


    void saveBudget();
private:
    void reportHours();
};
/********************
**  CLASS END
*********************/
#endif /* BUDGETCALCULATOR_H */
