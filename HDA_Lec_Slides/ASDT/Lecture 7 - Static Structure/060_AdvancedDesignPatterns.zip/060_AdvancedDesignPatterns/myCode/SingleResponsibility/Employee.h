/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : EMPLOYEE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef EMPLOYEE_H
#define EMPLOYEE_H
class Employee {
private:
    int employeeData;
public:

    void saveBudget();

    void reportHours();

    void calculatePay();
};
/********************
**  CLASS END
*********************/
#endif /* EMPLOYEE_H */
