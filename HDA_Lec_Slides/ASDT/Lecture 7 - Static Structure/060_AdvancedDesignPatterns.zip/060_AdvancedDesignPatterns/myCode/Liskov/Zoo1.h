/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : ZOO1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef ZOO1_H
#define ZOO1_H
#include "Animal1.h"
class Zoo {
private:
    /**@link aggregation*/
    Animal lnkAnimal;
};
/********************
**  CLASS END
*********************/
#endif /* ZOO1_H */
