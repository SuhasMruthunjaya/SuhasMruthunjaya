/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : BIRD.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef BIRD_H
#define BIRD_H
#include "Animal1.h"
class Bird : public Animal {
public:

    void fly();
};
/********************
**  CLASS END
*********************/
#endif /* BIRD_H */
