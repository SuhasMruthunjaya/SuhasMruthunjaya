/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : COMPANYLICENCE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef COMPANYLICENCE_H
#define COMPANYLICENCE_H
#include "Licence.h"
class CompanyLicence : public Licence {
private:
    int users;
public:

    void calcFee();
};
/********************
**  CLASS END
*********************/
#endif /* COMPANYLICENCE_H */
