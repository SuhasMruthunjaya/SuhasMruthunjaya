/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : ELEPHANT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef ELEPHANT_H
#define ELEPHANT_H
#include "Animal1.h"
class Elephant : public Animal {
};
/********************
**  CLASS END
*********************/
#endif /* ELEPHANT_H */
