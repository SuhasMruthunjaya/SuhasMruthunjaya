/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : PRIVATELICENCE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef PRIVATELICENCE_H
#define PRIVATELICENCE_H
#include "Licence.h"
class PrivateLicence : public Licence {
public:

    void calcFee();
};
/********************
**  CLASS END
*********************/
#endif /* PRIVATELICENCE_H */
