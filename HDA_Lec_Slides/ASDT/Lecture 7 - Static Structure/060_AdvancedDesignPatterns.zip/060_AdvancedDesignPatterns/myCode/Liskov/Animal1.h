/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : ANIMAL1.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef ANIMAL1_H
#define ANIMAL1_H
class Animal {
public:

    void walk();
};
/********************
**  CLASS END
*********************/
#endif /* ANIMAL1_H */
