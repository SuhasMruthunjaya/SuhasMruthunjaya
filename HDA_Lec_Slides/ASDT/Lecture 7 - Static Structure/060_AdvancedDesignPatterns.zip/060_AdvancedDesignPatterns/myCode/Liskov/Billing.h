/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : BILLING.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef BILLING_H
#define BILLING_H
#include "Licence.h"
class Billing {
private:
    /**@link aggregation
     * @supplierCardinality 0..**/
    Licence lnkLicence;
};
/********************
**  CLASS END
*********************/
#endif /* BILLING_H */
