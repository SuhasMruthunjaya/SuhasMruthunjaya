/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : LICENCE.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef LICENCE_H
#define LICENCE_H
class Licence {
public:

    virtual void calcFee() =0;
};
/********************
**  CLASS END
*********************/
#endif /* LICENCE_H */
