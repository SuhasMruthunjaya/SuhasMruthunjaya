/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CAT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CAT_H
#define CAT_H
#include "Animal1.h"
class Cat : public Animal {
};
/********************
**  CLASS END
*********************/
#endif /* CAT_H */
