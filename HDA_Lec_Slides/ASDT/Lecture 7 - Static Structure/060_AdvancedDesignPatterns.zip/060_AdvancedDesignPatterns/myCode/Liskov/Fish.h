/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : FISH.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef FISH_H
#define FISH_H
#include "Animal1.h"
class Fish : public Animal {
};
/********************
**  CLASS END
*********************/
#endif /* FISH_H */
