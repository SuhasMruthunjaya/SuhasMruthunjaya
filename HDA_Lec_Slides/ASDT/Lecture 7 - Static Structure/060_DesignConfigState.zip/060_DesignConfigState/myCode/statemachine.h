/**
 * \file 	statemachine.h
 * \author	Thomas Barth 				Hochschule Darmstadt - thomas.barth@h-da.de
 * \author	Prof.Dr.-Ing. Peter Fromm	Hochschule Darmstadt - peter.fromm@da.de
 * \date 	DateTime inactive during development
 *
 * \brief 	Software Component Central State Machine
 *
 * The central state machine defines the state of the car from a application perspective. This is not an error handler. It handles safety related events such as collision avoidance.
 *
 * Start of user code comments
 * 
 * End of user code
 *
 * ----- Changelog -----
 * Start of user code changelog
 * 
 * End of user code
 *
 * \copyright Copyright ?DateTime inactive during development
 * Department of electrical engineering and information technology, Hochschule Darmstadt - University of applied sciences (h_da). All Rights Reserved.
 * Permission to use, copy, modify, and distribute this software and its documentation for educational, and research purposes in the context of non-commercial
 * (unless permitted by h_da) and official h_da projects, is hereby granted for enrolled students of h_da, provided that the above copyright notice,
 * this paragraph and the following paragraph appear in all copies, modifications, and distributions.
 * Contact Prof.Dr.-Ing. Peter Fromm, peter.fromm@h-da.de, Birkenweg 8 64295 Darmstadt - GERMANY for commercial requests.
 *
 * \warning This software is a PROTOTYPE version and is not designed or intended for use in production, especially not for safety-critical applications!
 * The user represents and warrants that it will NOT use or redistribute the Software for such purposes.
 * This prototype is for research purposes only. This software is provided "AS IS," without a warranty of any kind.
 */
#ifndef SWC_CENTRAL_STATE_MACHINE_H
#define SWC_CENTRAL_STATE_MACHINE_H

/*=======================[ Includes ]==============================================================*/
//Start of user code usr_includes


#include "statemachine_config.h"
#include "statemachine_type.h"
#include "statemachine.cpp"


//End of user code

/*=======================[ Symbols ]===============================================================*/
//Start of user code usr_symbols

//End of user code

/*=======================[ Types ]=================================================================*/
//Start of user code usr_types

//End of user code

class CStatemachine
{

private:
    /**@link dependency*/
    /*# State_type lnkState_type; */
    /**@link dependency*/
    /*# Statemachine_config lnkStatemachine_config; */
    /**@link dependency*/
    /*# STATE__statetype_t lnkSTATE__statetype_t; */
public:
/*=======================[ Prototypes ]============================================================*/
//----------- Runnables
		
/**
 * \brief Runnable STATE_Init
 * initialization of state machine data
 * SIL:	QM;
 */
void STATE_Init(void);


//----------- User Functions

//Start of user code usr_prototypes

/**
 * @brief Calls the normal state machine
 * @param eventMask 	eventmask which will be processed
 */
void STATE_normal_processEvent(PxEvents_t eventMask);


/**
 * Calls the safety state machine
 * @param eventMask: events which will be processed
 */
void STATE_safety_processEvent(PxEvents_t eventMask);

//End of user code
};

#endif /* SWC_CENTRAL_STATE_MACHINE_H */
