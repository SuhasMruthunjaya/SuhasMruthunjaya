/**
 * \file	statemachine_type.h
 * \author	Prof.Dr.-Ing. Peter Fromm	Hochschule Darmstadt - peter.fromm@da.de
 * \date 	16.06.2016
 * \version	1.0
 *
 * \brief Contains general typedefinition for the state machine
 *
 *
 * \copyright Copyright �2018
 * Department of electrical engineering and information technology, Hochschule Darmstadt - University of applied sciences (h_da). All Rights Reserved.
 * Permission to use, copy, modify, and distribute this software and its documentation for educational, and research purposes in the context of non-commercial
 * (unless permitted by h_da) and official h_da projects, is hereby granted for enrolled students of h_da, provided that the above copyright notice,
 * this paragraph and the following paragraph appear in all copies, modifications, and distributions.
 * Contact Prof.Dr.-Ing. Peter Fromm, peter.fromm@h-da.de, Birkenweg 8 64295 Darmstadt - GERMANY for commercial requests.
 *
 * \warning This software is a PROTOTYPE version and is not designed or intended for use in production, especially not for safety-critical applications!
 * The user represents and warrants that it will NOT use or redistribute the Software for such purposes.
 * This prototype is for research purposes only. This software is provided "AS IS," without a warranty of any kind.
 */


#ifndef STATEMACHINE_TYPE_H_
#define STATEMACHINE_TYPE_H_

#include "global.h"
#include "UART_Remote_type.h"

class State_type
{

/******************************************************************************/
/*------------------------- Type Definitions ---------------------------------*/
/******************************************************************************/

#define FEATURE_NAME_MAX_LENGTH 			UART_REMOTE_PAYLOAD_SIZE  // Max length of features incl \0

/**
 * function pointer used for actions
 */
typedef void (*STATE_ActionPtr_t)();

/**
 * function pointer used for guards
 */
typedef bool (*STATE_GuardPtr_t)();



/**
 * State Transition
 */
typedef struct
{
	STATE_GuardPtr_t guard;
	STATE_ActionPtr_t actionTransition;
	uint32_t toState;
} STATE_stateTransition_t;

typedef STATE_stateTransition_t  STATE_stateTransitionTable_t[];

/**
 * State Action
 */
typedef struct
{
	STATE_ActionPtr_t actionEntry;
	// STATE_ActionPtr_t actionDo; //Not used, as state machine is called time triggered
	STATE_ActionPtr_t actionExit;
} STATE_stateAction_t;

typedef STATE_stateAction_t  STATE_stateActionTable_t[];

/**
 * Drive mode
 */
typedef struct
{
	STATE_ActionPtr_t init;
	STATE_ActionPtr_t drive;
	STATE_ActionPtr_t deInit;
	char featureName[FEATURE_NAME_MAX_LENGTH];
} STATE_driveAction_t;

typedef STATE_driveAction_t STATE_driveActionTable_t[];

};

#endif /* STATEMACHINE_TRANSITION_TYPE_H_ */
