/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CBUFFERCONFIG.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CBUFFERCONFIG_H
#define CBUFFERCONFIG_H
#include "machine.h"
class CBufferConfig {
private:
    /**@link dependency*/
    /*# machine_types lnkmachine_types; */

public:
	static const uint16_t m_maxSize = 100;
	static const uint16_t m_minSize = 10;
	static const uint16_t m_defaultSize = 20;
};
/********************
**  CLASS END
*********************/
#endif /* CBUFFERCONFIG_H */
