/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CUARTDRIVER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CUARTDRIVER_H
#define CUARTDRIVER_H
#include "CRingBuffer.h"
#include "machine.h"
class CUartDriver {
public:
	enum parity_t{EVEN, ODD, NONE};

private:
    uint32_t m_baudrate;
    parity_t m_parity;
    uint8_t m_dataBits;
    uint8_t  m_stopBits;
    CRingBuffer m_rxbuffer;
    CRingBuffer m_txbuffer;
    /**@link dependency*/
    /*# machine_types lnkmachine_types; */
public:

    CUartDriver(uint32_t baudrate = 115200, uint8_t data=8, parity_t parity=EVEN, uint8_t stop=1, uint16_t rxBufferSize = 10, uint16_t txBufferSize = 10);

    RC_t read(uint8_t& data);
    RC_t write(uint8_t data);

    void rx_isr();
    void tx_isr();

};
/********************
**  CLASS END
*********************/
#endif /* CUARTDRIVER_H */
