/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CRINGBUFFER.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CRINGBUFFER_H
#define CRINGBUFFER_H

#include "machine.h"
#include "CBufferConfig.h"

class CRingBuffer {
private:
    /**@link aggregationByValue*/

    uint16_t m_size;
    uint16_t m_fillLevel;
    uint16_t m_writeIndex;
    uint16_t m_readIndex;
    uint8_t* m_pBuffer;
    /**@link dependency*/
    /*# machine_types lnkmachine_types; */
public:

    CRingBuffer(uint16_t size = CBufferConfig::m_defaultSize);

    ~CRingBuffer();

    RC_t clear();

    RC_t write(uint8_t data);

    RC_t read(uint8_t& data);
};
/********************
**  CLASS END
*********************/
#endif /* CRINGBUFFER_H */
