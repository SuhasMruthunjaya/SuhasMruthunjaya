/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CRINGBUFFER.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files
#include "CRingBuffer.h"


//Method Implementations

CRingBuffer::CRingBuffer(uint16_t size)
{
	if (size >= CBufferConfig::m_minSize && size < CBufferConfig::m_maxSize)
	{
		m_size = size;
	}
	else
	{
		m_size = CBufferConfig::m_defaultSize;
	}

	m_fillLevel = 0;
	m_readIndex = 0;
	m_writeIndex = 0;

	m_pBuffer = new uint8_t[m_size];
}

CRingBuffer::~CRingBuffer()
{
	delete[] m_pBuffer;
}

RC_t CRingBuffer::write(uint8_t data)
{
	if (m_fillLevel < m_size)
	{
		m_pBuffer[m_writeIndex++] = data;

		m_writeIndex %= m_size;
		m_fillLevel++;

		return RC_SUCCESS;
	}
	else
	{
		return RC_BUFFEROVERFLOW;
	}
}

RC_t CRingBuffer::read(uint8_t &data)
{
	if (m_fillLevel > 0)
	{
		data = m_pBuffer[m_readIndex++];

		m_readIndex %= m_size;
		m_fillLevel--;

		return RC_SUCCESS;
	}
	else
	{
		return RC_BUFFERUNDERFLOW;
	}
}

