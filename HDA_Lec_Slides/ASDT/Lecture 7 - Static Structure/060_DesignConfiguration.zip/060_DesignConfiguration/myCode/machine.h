/*
 * machine.h
 *
 *  Created on: 21.11.2019
 *      Author: Fromm
 */

#ifndef MACHINE_H_
#define MACHINE_H_

#ifdef TOGETHER
class machine_types{
#endif


typedef unsigned int uint32_t;
typedef unsigned short uint16_t;
typedef unsigned char uint8_t;

typedef signed int sint32_t;
typedef signed short sint16_t;
typedef signed char sint8_t;

enum RC_t {RC_SUCCESS, RC_ERROR, RC_WRONPARAM, RC_BUFFERUNDERFLOW, RC_BUFFEROVERFLOW};

#ifdef TOGETHER
};
#endif



#endif /* MACHINE_H_ */
