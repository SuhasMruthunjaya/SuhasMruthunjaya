// Standard (system) header files
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>

using namespace std;

// Add your project's header files here
#include "ErrorWriter.h"
#include "CentralErrorHandler.h"
#include "CppErrorHandler.h"


//=======================================================================================================
//
// Central Error Handling

void terminateError()
{
	cerr << "Hard termination" << endl;
	terminate();
}

void terminateWarning()
{
	cerr << "No termination - program continues" << endl;
}


void test_CEH()
{

	fstream errorLog;
	errorLog.open("MyErrorLog", ios::out);

	ErrorWriter errorConsole;
	ErrorWriter errorFile(errorLog);

	//Using console output
	CentralErrorHandler hdl1(errorConsole, terminateWarning);
	hdl1.report(CEH_BUFFEREMPTY);

	//Using file output
	CentralErrorHandler hdl2(errorFile, terminateError);
	hdl2.report(CEH_BUFFEROVERRUN);	//This will not terminate, as the error is configured to continue
	hdl2.report(CEH_INVALIDPOINTER);


	errorLog.close();
}


//=======================================================================================================
//
// C++ try catch

// a = 0 - no error
// a = 1 - correctly thrown error
// a = 2 - bad throw
void foo (int a)
{
	switch (a)
	{
	case 0 : cout << "foo is happy, no error" << endl; break;
	case 1 : throw CppErrorHandler("bad param", "foo"); break;
	case 2 : throw 3; break; //Not really the correct type thrown...
	}
}

void test_CppErrorHandler(int a)
{
	try
	{
		foo(a);
		cout << "code continues normally" << endl;
	}
	catch (CppErrorHandler& err)
	{
		err.report();
	}
	catch (...) //all
	{
		cerr << "Ooops, this should not have happenend" << endl;
		terminate(); //Let's stop, as the error was not handled properly
	}

}


// Main program
int main (void)
{

	//Uncomment the testcase you want to run

	//test_CEH();

	// a = 0 - no error
	// a = 1 - correctly thrown error
	// a = 2 - bad throw
	//test_CppErrorHandler(2);


	return 0;
}
