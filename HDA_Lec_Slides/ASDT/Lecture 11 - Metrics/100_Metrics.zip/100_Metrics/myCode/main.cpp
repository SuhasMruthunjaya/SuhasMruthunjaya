// Standard (system) header files
#include <iostream>
#include <stdlib.h>
// Add more standard header files as required
// #include <string>

using namespace std;

// Add your project's header files here


/* Calculation Age at Entry */
int entryAge(int birthYear, int birthMonth, int entryYear, int entryMonth)
{
	int years, months;
	if ( entryMonth < birthMonth )
	{	months = 12 + entryMonth - birthMonth;
		years = entryYear - birthYear -1;
	}
	else
	{	months = entryMonth - birthMonth;
		years = entryYear - birthYear;
	}
	if ( months > 5)
	  	years = years + 1;
	return years;
}


unsigned int calculateTimeInMS(unsigned short hh, unsigned short mm, unsigned short ss)
{
   //Local variable holding the result
	unsigned int result = 0;

   //Add the individual time components
	result += hh * 3600;
	result += mm * 60;
	result += ss;

	//Translate into ms
	result *= 1000;

	//Return the final result
	return result;
}


// Main program
int main (void)
{
    // TODO: Add your program code here
	cout << "100_Metrics started." << endl << endl;

	return 0;
}
