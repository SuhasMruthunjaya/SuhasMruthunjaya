/*
 * CCoordinate.cpp
 *
 *  Created on: 10.01.2020
 *      Author: Fromm
 */

#include "CCoordinate.h"


CCoordinate::CCoordinate(float x, float y)
{
	m_x = x;
	m_y = y;
}


std::ostream& operator<<(std::ostream& out, CCoordinate const& rop)
{
	out << "(" << rop.m_x << ", " << rop.m_y << ")";
	return out;
}
