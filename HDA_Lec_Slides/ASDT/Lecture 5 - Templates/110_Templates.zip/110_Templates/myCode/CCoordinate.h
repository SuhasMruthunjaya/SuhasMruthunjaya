/*
 * CCoordinate.h
 *
 *  Created on: 10.01.2020
 *      Author: Fromm
 */

#ifndef CCOORDINATE_H_
#define CCOORDINATE_H_

#include <ostream>


class CCoordinate
{
	float m_x;
	float m_y;
public:
	CCoordinate(float x = 0, float y = 0);

	friend std::ostream& operator<<(std::ostream& out, CCoordinate const& rop);

};

#endif /* CCOORDINATE_H_ */
