/*
 * CRingbuffer.h
 *
 *  Created on: 10.01.2020
 *      Author: Fromm
 */

#ifndef CRINGBUFFER_H_
#define CRINGBUFFER_H_
#include "CRingbuffer.h"

#include <iostream>

template<class DATA = int>
class TCRingbuffer
{
private:
	unsigned short m_size;
	unsigned short m_readIdx;
	unsigned short m_writeIdx;
	unsigned short m_fillLevel;
	DATA* m_pBuffer;

public:
	TCRingbuffer(unsigned short size = 10);
	virtual ~TCRingbuffer();
	TCRingbuffer(const TCRingbuffer &other);

	bool put(DATA const& data);
	bool get(DATA& data);

	void print();
};

template<class DATA>
inline TCRingbuffer<DATA>::TCRingbuffer(unsigned short size)
{
	m_readIdx = 0;
	m_writeIdx = 0;
	m_fillLevel = 0;

	if (size == 0)
	{
		size = 10;
	}
	m_size = size;

	m_pBuffer = new DATA[m_size];
}

template<class DATA>
inline TCRingbuffer<DATA>::~TCRingbuffer()
{
	delete[] m_pBuffer;
}

template<class DATA>
inline TCRingbuffer<DATA>::TCRingbuffer(const TCRingbuffer &other)
{
	m_fillLevel = other.m_fillLevel;
	m_readIdx = other.m_readIdx;
	m_writeIdx = other.m_writeIdx;
	m_size = other.m_size;

	m_pBuffer = new int[m_size];

	//Deep copy
	for (unsigned short i = 0; i < m_size; i++)
	{
		m_pBuffer[i] = other.m_pBuffer[i];
	}

}

template<class DATA>
inline bool TCRingbuffer<DATA>::put(const DATA &data)
{
	if (m_fillLevel < m_size)
	{
		m_pBuffer[m_writeIdx++] = data;
		m_fillLevel++;
		m_writeIdx = m_writeIdx % m_size;
		return true;
	}
	return false;
}

template<class DATA>
inline bool TCRingbuffer<DATA>::get(DATA &data)
{
	if (m_fillLevel > 0)
	{
		data = m_pBuffer[m_readIdx++];
		m_readIdx = m_readIdx % m_size;
		m_fillLevel--;
		return true;
	}
	return false;
}

template<class DATA>
inline void TCRingbuffer<DATA>::print()
{
	for (unsigned short i = m_readIdx; i < m_readIdx + m_fillLevel; i++)
	{
		unsigned short index = i % m_size;
		std::cout << "Element at " << index << " : " << m_pBuffer[index] << std::endl;
	}
}

#endif /* CRINGBUFFER_H_ */
