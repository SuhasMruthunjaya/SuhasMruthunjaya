/*
 * mymath.h
 *
 *  Created on: 10.01.2020
 *      Author: Fromm
 */

#ifndef MYMATH_H_
#define MYMATH_H_

#define MIN(A,B) ((A)<(B) ? (A) : (B))

// A first template function
// Note, that the implementation is in the header file
template <typename T>
inline T min1(T const& a, T const& b)
{
	if (a < b)
	{
		return a;
	}
	else
	{
		return b;
	}
}

#if 0
// A specialised template function for pointers
// Note, that the implementation is in the header file
template <typename T>
inline T min1(T* a, T* b)	//const pointers will not work, because pointer in main was not declared const
{
	if (*a < *b)
	{
		return *a;
	}
	else
	{
		return *b;
	}
}
#endif

// A first template function
// Using export...
template <typename T>
T min2(T a, T b);


#endif /* MYMATH_H_ */
