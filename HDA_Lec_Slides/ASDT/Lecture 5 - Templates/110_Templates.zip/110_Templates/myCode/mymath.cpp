/*
 * mymath.cpp
 *
 *  Created on: 10.01.2020
 *      Author: Fromm
 */

#include "mymath.h"

//Depricated in C++x11
export
template <typename T>
T min2(T a, T b)
{
	if (a < b)
	{
		return a;
	}
	else
	{
		return b;
	}
}

