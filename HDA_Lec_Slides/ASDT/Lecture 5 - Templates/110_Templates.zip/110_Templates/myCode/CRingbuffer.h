/*
 * CRingbuffer.h
 *
 *  Created on: 10.01.2020
 *      Author: Fromm
 */

#ifndef CRINGBUFFER_H_
#define CRINGBUFFER_H_

class CRingbuffer
{
private:
	unsigned short m_size;
	unsigned short m_readIdx;
	unsigned short m_writeIdx;
	unsigned short m_fillLevel;
	int* m_pBuffer;

public:
	CRingbuffer(unsigned short size = 10);
	virtual ~CRingbuffer();
	CRingbuffer(const CRingbuffer &other);

	bool put(int data);
	bool get(int& data);
};

#endif /* CRINGBUFFER_H_ */
