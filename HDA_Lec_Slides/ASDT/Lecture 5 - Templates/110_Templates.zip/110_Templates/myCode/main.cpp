// Standard (system) header files
#include <iostream>
#include <string>

using namespace std;

// Add your project's header files here
#include "mymath.h"

#include "CCoordinate.h"
#include "TCRingbuffer.h"

// Main program
int main (void)
{

	int i1 = 2, i2 = 3;
	float f1 = 2.4, f2 = 4.5;
	string s1("Peter"), s2("Mary");

	int* pi1 = &i1, *pi2 = &i2;


	//Test with macro
	cout << "Test with macro" << endl;
	cout << " int: " << MIN(i1, i2) << endl;
	cout << " float: " << MIN(f1, f2) << endl;
	cout << " string: " << MIN(s1, s2) << endl;

	cout << " int pointer: " << MIN(pi1, pi2) << endl; //We might want to see the derefenced value here...
	cout << " int/float mixture: " << MIN(i2, f1) << endl; //What happens here?
	//cout << " int/string mixture: " << MIN(i2, s1) << endl;

	//Test with traditional template function
	cout << endl << "Test with template function" << endl;
	cout << " int: " << min1(i1, i2) << endl; // We have more than one min function in the system. Use local namespace
	cout << " float: " << min1(f1, f2) << endl;
	cout << " string: " << min1(s1, s2) << endl;
	cout << " pointer: " << min1(pi1, pi2) << endl;

	//cout << " string/int: " << min1(s1, i2) << endl;

	//cout << " const string: " << min1("abc", "ABC") << endl;

	//Test with external template function
	//Depricated and not implemnted, therefore linker throws an error
#if 0
	cout << " int: " << min2(i1, i2) << endl; // We have more than one min function in the system. Use local namespace
	cout << " float: " << min2(f1, f2) << endl;
	cout << " string: " << min2(s1, s2) << endl;
#endif


	//Test the templated class
	cout << "Templated class Ringbuffer" << endl;

	float data;

	TCRingbuffer<float> rbf(10);
	rbf.put(1.1);
	rbf.put(2.2);
	rbf.put(3.3);

	rbf.get(data);

	rbf.print();


	TCRingbuffer<CCoordinate> rbc(10);

	CCoordinate coord(4,4);
	//cout << coord << endl;

	rbc.put(CCoordinate(1,1));
	rbc.put(CCoordinate(2,2));
	rbc.put(CCoordinate(3,3));

	rbc.print();

	TCRingbuffer<> rbi(5);
	rbi.put(1);
	rbi.put(2);
	rbi.put(3);

	rbi.print();
	return 0;
}
