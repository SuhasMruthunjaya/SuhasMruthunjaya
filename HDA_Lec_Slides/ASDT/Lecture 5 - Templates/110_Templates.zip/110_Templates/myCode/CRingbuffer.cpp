/*
 * CRingbuffer.cpp
 *
 *  Created on: 10.01.2020
 *      Author: Fromm
 */

#include "CRingbuffer.h"

CRingbuffer::CRingbuffer(unsigned short size)
{
	m_readIdx = 0;
	m_writeIdx = 0;
	m_fillLevel = 0;

	if (size == 0)
	{
		size = 10;
	}
	m_size = size;

	m_pBuffer = new int[m_size];

}

CRingbuffer::~CRingbuffer()
{
	delete[] m_pBuffer;
}

CRingbuffer::CRingbuffer(const CRingbuffer &other)
{
	m_fillLevel = other.m_fillLevel;
	m_readIdx = other.m_readIdx;
	m_writeIdx = other.m_writeIdx;
	m_size = other.m_size;

	m_pBuffer = new int[m_size];

	//Deep copy
	for (unsigned short i = 0; i < m_size; i++)
	{
		m_pBuffer[i] = other.m_pBuffer[i];
	}

}

bool CRingbuffer::put(int data)
{
	if (m_fillLevel < m_size)
	{
		m_pBuffer[m_writeIdx++] = data;
		m_fillLevel++;
		m_writeIdx = m_writeIdx % m_size;
		return true;
	}
	return false;
}

bool CRingbuffer::get(int &data)
{
	if (m_fillLevel > 0)
	{
		data = m_pBuffer[m_readIdx++];
		m_readIdx = m_readIdx % m_size;
		m_fillLevel--;
		return true;
	}
	return false;
}
