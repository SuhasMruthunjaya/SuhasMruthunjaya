// Standard (system) header files
#include <iostream>
#include <stdlib.h>
// Add more standard header files as required
// #include <string>

using namespace std;

// Add your project's header files here
#include "Game.h"

// Main program
int main (void)
{

	ASDT::Game::state_t myState = ASDT::Game::ISIDLE;

	return 0;
}
