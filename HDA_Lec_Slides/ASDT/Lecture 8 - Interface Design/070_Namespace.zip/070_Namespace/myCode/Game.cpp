/*
 * Game.cpp
 *
 *  Created on: 05.12.2019
 *      Author: Fromm
 */

#include "Game.h"

using namespace ASDT; //Alternative ==> Game::Game()

ASDT::Game::Game()
{
	//Do something
}
