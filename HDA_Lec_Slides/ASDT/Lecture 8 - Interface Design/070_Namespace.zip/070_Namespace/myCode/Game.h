/*
 * Game.h
 *
 *  Created on: 05.12.2019
 *      Author: Fromm
 */

#ifndef GAME_H_
#define GAME_H_

namespace ASDT {

class Game
{
public:
	typedef enum {ISIDLE, ISRUNNING} state_t;

	Game();
}; //class

}; //namespace

#endif /* GAME_H_ */
