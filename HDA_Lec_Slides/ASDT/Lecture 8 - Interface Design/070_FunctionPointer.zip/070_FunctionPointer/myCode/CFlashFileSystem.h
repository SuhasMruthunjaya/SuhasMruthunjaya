/*
 * CFlashFileSystem.h
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#ifndef CFLASHFILESYSTEM_H_
#define CFLASHFILESYSTEM_H_

#include <string>


class CFlashFileSystem
{
public:
	/**
	 * Function Pointer for the error handler
	 */
	typedef void (*ErrorHandler_t)(std::string errorMessage);

private:
	ErrorHandler_t m_errHandler;
public:

	CFlashFileSystem(ErrorHandler_t errHdl = 0);

	virtual ~CFlashFileSystem();

	void writeFile(char const *const byteStream, unsigned short length);
};

#endif /* CFLASHFILESYSTEM_H_ */
