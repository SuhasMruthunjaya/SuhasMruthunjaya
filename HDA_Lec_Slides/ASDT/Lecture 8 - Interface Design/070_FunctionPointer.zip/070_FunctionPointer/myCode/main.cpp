// Standard (system) header files
#include <iostream>
#include <stdlib.h>
// Add more standard header files as required
// #include <string>

using namespace std;

// Add your project's header files here
#include "CApplication.h"
#include "CErrorHandler.h"
#include "CFunctorErrorHandler.h"


//Mixing Functor and Function Pointers

template <class T>
void functionTakingAnyErrorHandler(int paramA, int paramB, T errHdl)
{
	if (0 == paramA)
	{
		errHdl("A was 0");
	}

	if (0 == paramB)
	{
		errHdl("B was 0");
	}

}



// Main program
int main (void)
{
    // TODO: Add your program code here
	cout << "070_FunctionPointer started." << endl << endl;

	CApplication a;
	//a.runFctPtr();

	//a.runFunctor();

	//Using Fuction Pointers
	//functionTakingAnyErrorHandler(0,0,CErrorHandler::handlerWarning);
	//functionTakingAnyErrorHandler(0,0,CErrorHandler::handlerTerminate);

	//Using Functors
	functionTakingAnyErrorHandler(0,0, CFunctorErrorHandler(false) );
	functionTakingAnyErrorHandler(0,0, CFunctorErrorHandler(true) );


	return 0;
}
