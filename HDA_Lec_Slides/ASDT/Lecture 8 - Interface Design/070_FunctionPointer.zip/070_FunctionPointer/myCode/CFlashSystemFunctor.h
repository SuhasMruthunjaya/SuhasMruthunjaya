/*
 * CFlashFileSystem.h
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#ifndef CFLASHFILESYSTEMFUNCTOR_H_
#define CFLASHFILESYSTEMFUNCTOR_H_

#include <string>
#include "CFunctorErrorHandler.h"

class CFlashSystemFunctor
{

private:
    /**
     * @link aggregationByValue 
     */
	CFunctorErrorHandler m_errHandler;
public:


	CFlashSystemFunctor(CFunctorErrorHandler const& errHdl);

	virtual ~CFlashSystemFunctor();

	void writeFile(char const *const byteStream, unsigned short length);
};

#endif /* CFLASHFILESYSTEM_H_ */
