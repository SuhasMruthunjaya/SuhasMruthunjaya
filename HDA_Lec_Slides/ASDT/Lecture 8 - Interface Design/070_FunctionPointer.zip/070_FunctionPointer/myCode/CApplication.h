/*
 * CApplication.h
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#ifndef CAPPLICATION_H_
#define CAPPLICATION_H_
#include "CFunctorErrorHandler.h"

class CApplication
{
private:
    /**@link dependency*/
    /*# CFunctorErrorHandler lnkCFunctorErrorHandler; */
public:
	void runFctPtr();
	void runFunctor();
};

#endif /* CAPPLICATION_H_ */
