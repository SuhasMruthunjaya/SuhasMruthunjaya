
/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CFLASHSYSTEMFLEXIBLE.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files
#include "CFlashSystemFunctor.h"


//Method Implementations


CFlashSystemFunctor::CFlashSystemFunctor(const CFunctorErrorHandler &errHdl)
{
	m_errHandler = errHdl;
}

CFlashSystemFunctor::~CFlashSystemFunctor()
{
	//Will not work?
	//m_errHandler = 0;
}

void CFlashSystemFunctor::writeFile(const char *const byteStream,
		unsigned short length)
{
	//Todo: check for valid errHandler;

	if (0 == byteStream) {
		m_errHandler("Wrong param - byteStream points to 0");
	}

	if (0 == length) {
		m_errHandler("Wrong param - nothing to write, length is 0");
	}
}
