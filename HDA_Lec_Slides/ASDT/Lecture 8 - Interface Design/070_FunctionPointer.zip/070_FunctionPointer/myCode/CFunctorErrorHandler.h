/*
 * CFunctorErrorHandler.h
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#ifndef CFUNCTORERRORHANDLER_H_
#define CFUNCTORERRORHANDLER_H_

#include <string>

class CFunctorErrorHandler
{
private:
	bool m_terminateOnError;
public:
	CFunctorErrorHandler(bool terminateOnError = true);

	void operator()(std::string msg);
};

#endif /* CFUNCTORERRORHANDLER_H_ */
