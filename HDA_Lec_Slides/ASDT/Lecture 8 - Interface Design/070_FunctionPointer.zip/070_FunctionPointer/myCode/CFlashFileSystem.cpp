/*
 * CFlashFileSystem.cpp
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#include "CFlashFileSystem.h"



CFlashFileSystem::CFlashFileSystem(ErrorHandler_t errHandler)
{
	m_errHandler = errHandler;
}

CFlashFileSystem::~CFlashFileSystem()
{
	m_errHandler = 0;
}

void CFlashFileSystem::writeFile(const char *const byteStream,
		unsigned short length)
{

	//Todo: check for valid errHandler;

	if (0 == byteStream) {
		m_errHandler("Wrong param - byteStream points to 0");
	}

	if (0 == length) {
		m_errHandler("Wrong param - nothing to write, length is 0");
	}

}
