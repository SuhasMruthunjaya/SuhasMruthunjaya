/*
 * CFunctorErrorHandler.cpp
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#include <iostream>
using namespace std;

#include "CFunctorErrorHandler.h"



CFunctorErrorHandler::CFunctorErrorHandler(bool terminateOnError)
{
	m_terminateOnError = terminateOnError;
}

void CFunctorErrorHandler::operator ()(std::string msg)
{
	cerr << "ERROR: " << msg << endl;

	if (true == m_terminateOnError) {
		terminate();
	}

}
