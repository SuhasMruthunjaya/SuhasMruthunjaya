/*
 * CApplication.cpp
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#include "CApplication.h"

#include "CFlashFileSystem.h"
#include "CFlashSystemFunctor.h"
#include "CErrorHandler.h"
#include "CFunctorErrorHandler.h"

void CApplication::runFctPtr()
{

	CFlashFileSystem fs1(CErrorHandler::handlerWarning);
	fs1.writeFile(0,0);

	CFlashFileSystem fs2(CErrorHandler::handlerTerminate);
	fs2.writeFile(0,0);

	/*
	CFunctorErrorHandler hardhandler(true);
	CFunctorErrorHandler softhandler(false);
	 */


	//CFlashFileSystem fs1( hardhandler() );
	//fs1.writeFile(0,0);



}

void CApplication::runFunctor()
{


	CFlashSystemFunctor fsSoftFault(CFunctorErrorHandler(false));
	fsSoftFault.writeFile(0,0);

	CFlashSystemFunctor fsHardFault(CFunctorErrorHandler(true));
	fsHardFault.writeFile(0,0);
}
