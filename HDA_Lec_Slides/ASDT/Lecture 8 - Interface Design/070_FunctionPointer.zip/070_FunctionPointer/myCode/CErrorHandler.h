/*
 * CErrorHandler.h
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#ifndef CERRORHANDLER_H_
#define CERRORHANDLER_H_

#include <string>

class CErrorHandler
{
public:
	static void handlerWarning(std::string text);
	static void handlerTerminate(std::string text);

};

#endif /* CERRORHANDLER_H_ */
