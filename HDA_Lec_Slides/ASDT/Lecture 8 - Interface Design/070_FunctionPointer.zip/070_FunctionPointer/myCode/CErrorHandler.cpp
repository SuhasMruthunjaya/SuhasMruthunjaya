/*
 * CErrorHandler.cpp
 *
 *  Created on: 03.12.2019
 *      Author: Fromm
 */

#include <iostream>
using namespace std;


#include "CErrorHandler.h"


void CErrorHandler::handlerWarning(std::string text)
{
	cerr << "Error: " << text << endl;
}

void CErrorHandler::handlerTerminate(std::string text)
{
	cout << "Error: " << text << endl;
	terminate();
}
