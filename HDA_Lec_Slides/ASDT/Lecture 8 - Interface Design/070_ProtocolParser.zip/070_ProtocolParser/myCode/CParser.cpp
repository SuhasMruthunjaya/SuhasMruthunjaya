/*
 * CParser.cpp
 *
 *  Created on: 01.12.2019
 *      Author: Fromm
 */

#include "CParser.h"

#include <string>
using namespace std;

CParser::CParser(CPort &portA, CPort &portB)
{
	m_portA = &portA;
	m_portB = &portB;
}

RC_t CParser::transmit()
{

	if (0 == m_portA || 0 == m_portB)
	{
		return RC_ERROR;
	}

	RC_t result = RC_ERROR;
	//Transmit from A to B
	string data;

	//Read the data
	result = m_portA->readByteStream(data);

	//Do something with the data

	//Write the data
	result = m_portB->writeByteStream(data);

	return result;
}

CParser::CParser(CPortFactory::port_t portA, CPortFactory::port_t portB)
{
	m_portA = CPortFactory::createPort(portA);
	m_portB = CPortFactory::createPort(portB);
}

CParser::~CParser()
{
	m_portA = 0;
	m_portB = 0;
}

