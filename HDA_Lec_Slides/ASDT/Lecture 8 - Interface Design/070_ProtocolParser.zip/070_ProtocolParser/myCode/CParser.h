/*
 * CParser.h
 *
 *  Created on: 01.12.2019
 *      Author: Fromm
 */

#ifndef CPARSER_H_
#define CPARSER_H_

#include "global.h"
#include "CPort.h"
#include "CPortFactory.h"


class CParser
{
private:
	CPort* m_portA;
	CPort* m_portB;
public:
	/**
	 * Constructor taking explicit port objects
	 */
	CParser(CPort& portA, CPort& portB);

	/**
	 * Contructor, using the default factory settings
	 */
	CParser(CPortFactory::port_t portA,  CPortFactory::port_t portB);

	RC_t transmit();

	virtual ~CParser();
};

#endif /* CPARSER_H_ */
