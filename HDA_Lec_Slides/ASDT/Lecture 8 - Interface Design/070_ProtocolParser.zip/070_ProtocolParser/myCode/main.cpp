// Standard (system) header files
#include <iostream>
#include <stdlib.h>
// Add more standard header files as required
// #include <string>

using namespace std;

// Add your project's header files here
#include "CPort.h"
#include "CParser.h"
#include "CUartPort.h"
#include "CCanPort.h"

#include "CPortFactory.h"

// Main program
int main (void)
{
    // TODO: Add your program code here
	cout << "070_ProtocolParser started." << endl << endl;

	//CUartPort uart1;
	//uart1.writeByteStream("Hello world");



	//Let's create the parser
	CUartPort uart;
	CCanPort can;

	CParser parser(uart, can);
	parser.transmit();

	//Simplified API using the factory pattern
	CParser simpleParser(CPortFactory::UART, CPortFactory::CAN);
	simpleParser.transmit();

	return 0;
}
