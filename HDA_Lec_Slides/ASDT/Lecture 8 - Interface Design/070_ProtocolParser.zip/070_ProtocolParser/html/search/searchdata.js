var indexSectionsWithContent =
{
  0: "aceglmnoprsuw",
  1: "c",
  2: "cgm",
  3: "cmrw",
  4: "lm",
  5: "su",
  6: "pr",
  7: "aenor",
  8: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

