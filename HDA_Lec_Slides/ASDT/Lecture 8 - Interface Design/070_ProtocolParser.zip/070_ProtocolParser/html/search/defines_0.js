var searchData=
[
  ['uart_5fdefaultbuffersize_82',['UART_DEFAULTBUFFERSIZE',['../_c_uart_port_8h.html#a961e469c3926d09c99b99f43d1aefbc0',1,'CUartPort.h']]]
];
