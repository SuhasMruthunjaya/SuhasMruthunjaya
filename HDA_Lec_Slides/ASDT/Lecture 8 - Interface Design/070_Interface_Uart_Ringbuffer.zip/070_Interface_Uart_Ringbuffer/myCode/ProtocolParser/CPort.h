/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CPORT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CPORT_H
#define CPORT_H
class CPort {
public:

    CPort();
};
/********************
**  CLASS END
*********************/
#endif /* CPORT_H */
