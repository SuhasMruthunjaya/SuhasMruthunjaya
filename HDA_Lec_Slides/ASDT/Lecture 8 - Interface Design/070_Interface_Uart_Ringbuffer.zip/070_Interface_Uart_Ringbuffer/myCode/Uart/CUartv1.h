/*
 * CUartv1.h
 *
 *  Created on: 01.12.2019
 *      Author: Fromm
 */

#ifndef CUARTV1_H_
#define CUARTV1_H_
#include <stdint.h>

class CUart_v1
{
public:
enum port_t{ASCLIN1, ASCLIN2, ASCLIN3, ASCLIN5, ASCLIN5, NONE};

enum parity_t{ODD, EVEN, NONE};

CUart_v1(port_t port = NONE,
         uint16_t baudrate = 115200,
         uint8_t bits = 8,
         parity_t parity = NONE,
         uint8_t stopbits = 1);
};

class CUart_v2
{
public:

	CUart_v2(uint16_t *const configReg,
		     uint16_t *const baudReg1,
		     uint16_t *const baudReg2,
		     uint16_t configRegValue,
			 int16_t baudReg1Value,
		     uint16_t baudReg2Value);
};


#endif /* CUARTV1_H_ */
