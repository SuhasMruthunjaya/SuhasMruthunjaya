/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CDATABASEREPLICATION.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CDATABASEREPLICATION_H
#define CDATABASEREPLICATION_H
#include "CAccount.h"
class CDatabaseReplication {
public:

    CDatabaseReplication(unsigned short noELements);

private:

    unsigned short m_nextFree;
    unsigned short m_size;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1..**/
    CAccount* m_accountDatabase;
public:

    void payIntoAccount(unsigned int account, float amount);

    void checkForAccount(unsigned int account, float amount);


    void withdrawFromAccount(unsigned int accountNo, float amount);

    void authenticateUser(unsigned int account, unsigned short pin);

private:
    CAccount& SearchAccount(unsigned int accontNo);


};
/********************
**  CLASS END
*********************/
#endif /* CDATABASEREPLICATION_H */
