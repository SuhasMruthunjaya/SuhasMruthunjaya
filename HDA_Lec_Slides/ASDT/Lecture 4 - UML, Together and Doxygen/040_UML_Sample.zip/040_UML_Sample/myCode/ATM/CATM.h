/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CATM.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CATM_H
#define CATM_H
#include "CDatabaseReplication.h"
#include "CMoneySlot.h"
#include "CKeyboard.h"
#include "CScreen.h"
class CATM {
private:
    /**@link aggregationByValue
     * @supplierCardinality 1
     * @clientCardinality 1*/
    CDatabaseReplication m_databaseReplication;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1*/
    CMoneySlot m_moneySlot;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1*/
    CKeyboard m_keyboard;
    /**@link aggregationByValue
     * @clientCardinality 1
     * @supplierCardinality 1*/
    CScreen m_screen;
    bool m_authenticated;
public:

    void withdrawMoney(unsigned short amount);
};
/********************
**  CLASS END
*********************/
#endif /* CATM_H */
