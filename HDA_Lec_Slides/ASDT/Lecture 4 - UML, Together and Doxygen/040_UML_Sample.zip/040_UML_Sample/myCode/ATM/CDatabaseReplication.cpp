#include "CDatabaseReplication.h"
#include "CAccount.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CDATABASEREPLICATION.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

void CDatabaseReplication::withdrawFromAccount(unsigned int accountNo){}
void CDatabaseReplication::payIntoAccount(unsigned int account, unsigned int amount){}
void CDatabaseReplication::checkForAccount(unsigned int account, unsigned int amount){}
CAccount& CDatabaseReplication::SearchAccount(unsigned int accontNo){}
CDatabaseReplication::CDatabaseReplication(unsigned short noELements){}
void CDatabaseReplication::operation1(){}
