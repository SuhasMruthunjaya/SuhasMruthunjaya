#include "CAccount.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CACCOUNT.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

unsigned short CAccount::getPin(){}
unsigned int CAccount::getAccountNo(){}
