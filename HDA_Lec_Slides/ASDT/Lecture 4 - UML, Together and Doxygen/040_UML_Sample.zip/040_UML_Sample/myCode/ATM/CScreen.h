/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CSCREEN.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CSCREEN_H
#define CSCREEN_H
class CScreen {
public:

    void printMessage(string message);
};
/********************
**  CLASS END
*********************/
#endif /* CSCREEN_H */
