#include "CMoneySlot.h"

/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CMONEYSLOT.CPP
* Author          :
* Description     :
*
*
****************************************************************************/


//System Include Files


//Own Include Files

//Method Implementations

void CMoneySlot::deliver(unsigned int amount){}
CMoneySlot::CMoneySlot(){}
