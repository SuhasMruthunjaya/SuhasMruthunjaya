/***************************************************************************
*============= Copyright by Darmstadt University of Applied Sciences =======
****************************************************************************
* Filename        : CACCOUNT.H
* Author          :
* Description     :
*
*
****************************************************************************/

#ifndef CACCOUNT_H
#define CACCOUNT_H
class CAccount {
private:
    unsigned short m_pin;
    unsigned float m_deposit;
    unsigned int m_accountNo;
    string m_customer;
public:

    unsigned int getAccountNo();

    unsigned short getPin();
};
/********************
**  CLASS END
*********************/
#endif /* CACCOUNT_H */
