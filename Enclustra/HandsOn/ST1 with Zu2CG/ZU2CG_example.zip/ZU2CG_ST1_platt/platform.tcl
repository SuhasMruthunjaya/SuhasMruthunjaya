# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct C:\Users\SESA630813\work-2\ZU2CG_ST1_platt\platform.tcl
# 
# OR launch xsct and run below command.
# source C:\Users\SESA630813\work-2\ZU2CG_ST1_platt\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {ZU2CG_ST1_platt}\
-hw {C:\Schneider\ScriptingPath\enclustra\2CG_ST1_Handson\ZU2CG_HandsOn_wrapper.xsa}\
-proc {psu_cortexa53_0} -os {standalone} -arch {64-bit} -fsbl-target {psu_cortexa53_0} -out {C:/Users/SESA630813/work-2}

platform write
platform generate -domains 
platform active {ZU2CG_ST1_platt}
platform generate
platform config -updatehw {C:/Schneider/ScriptingPath/enclustra/2CG_ST1_Handson/ZU2CG_HandsOn_wrapper.xsa}
platform generate -domains 
